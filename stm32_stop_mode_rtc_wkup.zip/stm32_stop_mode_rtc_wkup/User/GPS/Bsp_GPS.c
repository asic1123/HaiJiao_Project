#include "Bsp_GPS.h"
#include "ParaManager.h"
#include "CompileConfig.h"
#include <string.h>
#include <stdlib.h>
#include "ProcessManager.h"
#include "DataManager.h"
#include "PublicFunc.h"
#include "bsp_rtc.h"
#include "bsp_date.h"
#include "pcf8563.h"

#define GPS_DATA_MAX 128
#define GPS_USART USART3

char gpsData[GPS_DATA_MAX];
char gpsDAta_Test[GPS_DATA_MAX];
char curGpsData[GPS_DATA_MAX];

uint8_t curGpsDataSize = 0;
uint8_t m_gpsIsOnline = 0;
uint8_t curGpsDataCount = 0;

uint32_t m_gpsDataCount = 0;
uint8_t m_gpsTimeIsUpdated = 0;
uint8_t needGpsToGprs = 0;


int cmdCurrentIndex = 0;
int cmdCount = 0;
char cmd_GPS[64] = {0};

double Dimension = 0; //ά��
double Longitude = 0; //����

void InitGpsData()
{
	memset(gpsData,0,GPS_DATA_MAX*sizeof(uint8_t));
	curGpsDataSize = 0;
}

void setGPSCmd(char cmd)
{
	memset(cmd_GPS,0,64);
	if(cmd == 0) //ֻ����GPS�ź�
	{
		sprintf(cmd_GPS,"%s","$PMTK353,1,0,0,0,0*2A");
	}
	else if(cmd == 1) //GPS+����˫ģģʽ
	{
		sprintf(cmd_GPS,"%s","$PMTK353,1,0,0,0,1*2B");
	}
	else if(cmd == 2) //����ģʽ
	{
		sprintf(cmd_GPS,"%s","$PMTK353,0,0,0,0,1*2A");
	}
	else
	{
		sprintf(cmd_GPS,"%s","$PMTK353,1,0,0,0,1*2B");
	}
	
	cmdCurrentIndex = 0;
	cmdCount = strlen(cmd_GPS);
	
	USART_ITConfig(GPS_USART, USART_IT_TXE, ENABLE);	
}

void sendNextGPSCmdCh(void)
{
		if( cmdCurrentIndex >= cmdCount )//TC��Ҫ ��SR+дDR ������0,�����͵����,��'\0'��ʱ���ø�if�жϹص�
	 {
			USART_ClearFlag(GPS_USART, USART_FLAG_TC);//��ȻTCһֱ��set, TCIEҲ�Ǵ򿪵�,���»᲻ͣ�����ж�. clear������,���ùص�TCIE
			USART_ITConfig(GPS_USART, USART_IT_TXE, DISABLE);
	 }
   else
	 {
			USART_SendData(GPS_USART, cmd_GPS[cmdCurrentIndex]);
			cmdCurrentIndex++;
	 }
}

void AddGpsData(uint8_t ch)
{
	if(curGpsDataSize < GPS_DATA_MAX)
	{
		gpsData[curGpsDataSize] = ch;
		curGpsDataSize++;
	}
}

void AnalyGpsData(void)
{
	char delims[] = ",";
	char *result = NULL;
	char time[10];
	char date[10];

	static double tmpD = 0;
	static double tmpL = 0;
	
	struct rtc_time curDateTime;

	if(m_gpsTimeIsUpdated == 0)
		m_gpsDataCount++;

	//--Time
	result = strtok( curGpsData, delims );		//GPRMC
	if(result == NULL)
		return;
	
  result = strtok( NULL, delims );				//ʱ��
	if(result == NULL)
		return;
	
	strcpy(time,result);
	
	if(strlen(time) < 6)
		return;
	
	//---Judge
	result = strtok( NULL, delims );
	if(result == NULL)
		return;
	
	if(memcmp(result,"A",1) != 0)
	{
		m_gpsIsOnline = 0;
		return;
	}
	
	//---Dimension
	result = strtok( NULL, delims );		//ά��
	if(result == NULL)
		return;
	
	Dimension = atof(result);
	//--Longitude
	result = strtok( NULL, delims );	//N
	if(result == NULL)
		return;
	
	result = strtok( NULL, delims );		//����
	if(result == NULL)
		return;
	
	Longitude = atof(result);
	
	//--Date
	result = strtok( NULL, delims );	//E
	if(result == NULL)
		return;
	
	result = strtok( NULL, delims ); 
	if(result == NULL)
		return;
	
	result = strtok( NULL, delims );
	if(result == NULL)
		return;
	
	result = strtok( NULL, delims );		//Date
	if(result == NULL)
		return;
	

	strcpy(date,result);
	
	if(strlen(date) < 6)
		return;
	
	curDateTime.tm_year = getUint16FromStr(date+4,2) + 2000;
	curDateTime.tm_mon = getUint16FromStr(date+2,2);
	curDateTime.tm_mday = getUint16FromStr(date,2);
	curDateTime.tm_hour = getUint16FromStr(time,2) + 8;
	curDateTime.tm_min = getUint16FromStr(time+2,2);
	curDateTime.tm_sec = getUint16FromStr(time+4,2);
	
	if(curDateTime.tm_hour >= 24) return; //ʹ���з�����ʱ����30������
	
	Time_Get();
	
	#if (HYDRAU_FORMAT == 0)
	if(m_gpsTimeIsUpdated == 0 || isValidTime() == 0 || fabs(subSec(&curDateTime,&systmtime)) > 2*60) //ʵʱ����
	#else
	if(m_gpsTimeIsUpdated == 0 || isValidTime() == 0) //������һ��
	#endif
	{
		m_gpsTimeIsUpdated = 1;
		setDateTime(&curDateTime);
	}
	
	if(m_gpsDataCount > 100)
	{
		m_gpsTimeIsUpdated = 1;
	}

	m_gpsIsOnline = 1;
	
	if(needGpsToGprs)
	{
		if(curGpsDataCount == 0)
		{
			tmpD = Dimension;
			tmpL = Longitude;
			curGpsDataCount++;
		}
		else if(curGpsDataCount < 10)
		{
			tmpD += Dimension;
			tmpL += Longitude;
			curGpsDataCount++;
		}
		else
		{
			tmpD /= curGpsDataCount;
			tmpL /= curGpsDataCount;
			
			needGpsToGprs = 0;
			DisableGpsUpdate();
			PrepareSendGpsData();
		}
	}
}

void AskForGpsToGprs(void)
{
#ifdef WITH_GPS_FUNC
	needGpsToGprs = 1;
	curGpsDataCount = 0;
	EnableGpsUpdate();
#endif
}

void EnableGpsUpdate(void)
{
#ifdef WITH_GPS_FUNC
	USART_ITConfig(GPS_USART, USART_IT_RXNE, ENABLE);
#endif
}

void DisableGpsUpdate(void)
{
#ifdef WITH_GPS_FUNC
	USART_ITConfig(GPS_USART, USART_IT_RXNE, DISABLE);
#endif
}

void PrepareGpsData(void)
{
#ifdef WITH_GPS_FUNC
	if(strncmp(gpsData,"GPRMC",5) == 0 || strncmp(gpsData,"GNRMC",5) == 0 || strncmp(gpsData,"BDRMC",5) == 0)
//	if(strncmp(gpsData,"GNRMC",5) == 0) //˫ģ
	{
		memcpy(curGpsData,gpsData,GPS_DATA_MAX);
		PrepareAnalyGpsData();
	}
#endif
}

uint8_t GpsIsOnline(void)
{
#ifdef WITH_GPS_FUNC
	return m_gpsIsOnline;
#else
	return 0;
#endif
}
/*********************************************END OF FILE**********************/
