#include "Bsp_CH4.h"
#include "ParaManager.h"
#include "CompileConfig.h"
#include <string.h>
#include <stdlib.h>
#include "ProcessManager.h"
#include "PublicFunc.h"
#include "DataManager.h"

#include "PublicFunc.h"

#define CH4_DATA_MAX 64
#define CH4_USART UART4

char ch4Data[CH4_DATA_MAX];
char ch4DAta_Test[CH4_DATA_MAX];
char curCh4Data[CH4_DATA_MAX];

uint8_t curCh4DataSize = 0;
uint8_t curCh4DataCount = 0;
uint32_t m_ch4DataCount = 0;
uint8_t m_ch4TimeIsUpdated = 0;
uint8_t needCh4ToGprs = 0;

//int cmdCurrentIndex = 0;
//int DataCount = 0;
char cmd_CH4[64] = {0};

double MethConcetration;
double LightIntensity;

void InitCh4Data()
{
	memset(ch4Data,0,CH4_DATA_MAX*sizeof(uint8_t));
	curCh4DataSize = 0;
}

void AddCh4Data(uint8_t ch)
{
	if(curCh4DataSize < CH4_DATA_MAX)
	{
		ch4Data[curCh4DataSize] = ch;
		curCh4DataSize++;
	}
}

void AnalyCh4Data(void)
{
	char delims[] = " ";
	char *result = NULL;
	char time[10];
	char date[10];

	static double tmpD = 0;
	static double tmpL = 0;

	//--Time
	result = strtok( curCh4Data, delims );	//Ũ��
	if(result == NULL)
		return;
	
	MethConcetration = atof(result);
	result = strtok( NULL, delims );		//��ǿ
	if(result == NULL)
		return;
	
	LightIntensity = atof(result);
	result = strtok( NULL, delims ); 		//TEC
	if(result == NULL)
		return;
	
	if(needCh4ToGprs)
	{
		if(curCh4DataCount == 0)
		{
			tmpD = Dimension;
			tmpL = Longitude;
			curCh4DataCount++;
		}
		else if(curCh4DataCount < 10)
		{
			tmpD += Dimension;
			tmpL += Longitude;
			curCh4DataCount++;
		}
		else
		{
			tmpD /= curCh4DataCount;
			tmpL /= curCh4DataCount;
			
			needCh4ToGprs = 0;
			DisableCh4Update();
			//����eeprom����
		}
	}
}

void AskForCh4ToGprs(void)
{
	needCh4ToGprs = 1;
	curCh4DataCount = 0;
	EnableCh4Update();
}

void EnableCh4Update(void)
{
	USART_ITConfig(CH4_USART, USART_IT_RXNE, ENABLE);
}

void DisableCh4Update(void)
{
	USART_ITConfig(CH4_USART, USART_IT_RXNE, DISABLE);
}

void PrepareCh4Data(void)
{
	static int ch4Count = 0;
	if(ch4Count < 10) //���ʱ�����
	{
		ch4Count++;
	}else{
		ch4Count = 0;
		memcpy(curCh4Data,ch4Data,CH4_DATA_MAX);
		PrepareAnalyCh4Data();
	}
}

/*********************************************END OF FILE**********************/
