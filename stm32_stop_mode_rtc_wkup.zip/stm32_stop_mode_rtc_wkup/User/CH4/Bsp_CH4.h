#ifndef __BSP_CH4_H
#define	__BSP_CH4_H

#include "stm32f10x.h"
#include <stdio.h>

void InitCh4Data(void);
void AddCh4Data(uint8_t ch);
void AnalyCh4Data(void);
void PrepareCh4Data(void);

void EnableCh4Update(void);
void DisableCh4Update(void);

extern double MethConcetration;
extern double LightIntensity;
#endif /* __BSP_CH4_H */
