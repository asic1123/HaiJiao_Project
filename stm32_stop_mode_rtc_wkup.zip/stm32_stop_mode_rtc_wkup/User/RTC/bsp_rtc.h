

#ifndef __RTC_H
#define	__RTC_H

#include "bsp_date.h"
#include "CompileConfig.h"

#if RTC_TYPE == 0

extern struct rtc_time systmtime;

void RTC_CheckAndConfig(void);
void Time_Get(void);
void setDateTime(struct rtc_time *tm);

uint8_t isValidTime(void);

u8 Is_Leap_Year(u16 year);

#endif

#endif /* __XXX_H */
