#include "CompileConfig.h"
#include "ProcessManager.h"
#include "WatchDog.h"
#include "stm32f10x.h"
#include "delay.h"
#include "string.h"
#include "pcf8563.h"
#include "bsp_rtc.h"
#include "math.h"
#include "bsp_GPRS.h"
#include "math.h"
#include "DataManager.h"
#include "DataConfig.h"
#include "DataStructConfig.h"
#include "Bsp_GPS.h"
#include "Bsp_CH4.h"
#include "Bsp_RFID.h"
#include "bsp_gpio.h"
#include "bsp_usart.h"
#include "bsp_24cxx.h"
#include "sht85_iic.h"
#include "bsp_usart.h"


uint32_t lastCmdCount = 0;

uint8_t m_bCurTestIsOn = 0;
uint8_t needSendGPRSData= 0;
uint8_t needSendGPRSDataTest= 0;
uint8_t needSendState = 1;

uint8_t needAnalyGpsData = 0;
uint8_t needAnalyCh4Data = 0;

uint8_t needSendGpsData = 0;
//-----------Private------------------

void tryUpdateRealTime(void)
{
	Time_Get();
}

void tryUpdateMethData(void)
{
	updataMethData();
}

void tryUploadDataToServer(void)
{
	static uint32_t lastWeldDataSendDelay = 0;
	u8 tmpData[4];
	static uint16_t index;
	
	if(lastWeldDataSendDelay > 200000)		//��ʼ����ʱ
	{
		if(isGprsTransOn())
		{
			lastWeldDataSendDelay -= 1000;		//�����
			return;
		}
		
		//++slj 16-5-23��������ʱ�������ϴ����ź���ʾ����
		if(gprsIsConnected() != 1)
		{
			lastWeldDataSendDelay -= 1000;		//�����
			return;
		}		
		
		if(needSendGPRSData)
		{
			ReadMethInfo();

			if(MethInfo.index_tail <=MethInfo.index_head)
			{				
				outputGprsData(MethInfo.index_tail);
				MethInfo.index_tail++;
				WriteMethInfo(); //�ϴ�ʧ���� �������������
				needSendGPRSData = 0;
			}
		}else if(needSendGPRSDataTest)
		{
			outputGprsDataTest();
			needSendGPRSDataTest = 0;
		}
				
		lastWeldDataSendDelay -= 1000;		//�����
	}
	else
		lastWeldDataSendDelay++;;
}

void tryAnalyGpsData(void)
{
	if(needAnalyGpsData)
	{
		needAnalyGpsData = 0;
		AnalyGpsData();
	}
}

void tryAnalyCh4Data(void)
{
	if(needAnalyCh4Data)
	{
		needAnalyCh4Data = 0;
		AnalyCh4Data();
	}
}

//------------Public----------------------
void System_Reboot(void)  //����ϵͳ
{
		GPRS_Reset();
		NVIC_SystemReset();
}

void resetAllState(void)
{

}

void ProcessNext(void)
{
	
	tryUpdateRealTime(); //����ʱ��
	feedWatchDog();
	
	tryUpdateMethData(); //ÿ��1Сʱ��������
	feedWatchDog();
	
	tryOutputGprsData(); //��������
	feedWatchDog();
	
//	tryAnalyGpsData();	//GPS
//	feedWatchDog();
	
//	tryAnalyCh4Data();	//CH4
//	feedWatchDog();
	
	processRFID();
	feedWatchDog();		//RFID
	
//	if(gprsIsConnected() != 1)
//	{
//		tryToConnectGprs();
//		feedWatchDog();
//	}	

//	tryUploadDataToServer();
//	feedWatchDog();
				
	tryClearAllData();	
}
		
/*
uint8_t CurAuthorizationState(void)
{
	return m_authorizationState;
}
*/
/*
void setAuthorizationState(uint8_t val)
{
	m_authorizationState = val;
}
*/

/*
void Authorize(char* workNum,char* validity)
{
	if(workNum != NULL)
	{
		memset(InfoConfig.WelderNumber,'-',WELDER_NUM_LEN);
		memcpy(InfoConfig.WelderNumber,workNum,(strlen(workNum) > WELDER_NUM_LEN)?WELDER_NUM_LEN:strlen(workNum));
		
		if(strlen(validity) != 8)
			m_authorizationState = 2;
		else
		{
#ifdef WITH_REAL_TIME_CLOCK
			//��鱣��ʱ��
			Time_Get();
			feedWatchDog();
			
			m_authorizationState = 2;
			
			if(getUint16FromStr(validity,4) > systmtime.tm_year)
			{
				m_authorizationState = 0;
			}
			else if(getUint16FromStr(validity,4) == systmtime.tm_year)
			{
				if(getUint16FromStr(validity+4,2) > systmtime.tm_mon)
				{
					m_authorizationState = 0;
				}
				else if(getUint16FromStr(validity+4,2) == systmtime.tm_mon && getUint16FromStr(validity+6,2) >= systmtime.tm_mday)
				{
					m_authorizationState = 0;
				}
			}
#else
			m_authorizationState = 0;
#endif
		}	
		
		UpdatePage();
	}
}
*/

void PrepareAnalyGpsData(void)
{
	needAnalyGpsData = 1;
}

void PrepareAnalyCh4Data(void)
{
	needAnalyCh4Data = 1;
}

void PrepareSendGpsData(void)
{
	needSendGpsData = 1;
}

void Init_Start(void)
{
	Init_GPIO_Config();
	
	//SHT85_CheckAndConfig();
	
	I2C_EE_Init();
	
//	initSysConfig();
	
	initGPRS();
	
	USART_Config();
		
	InitRFID();
}

void Init_Stop(void)
{
	Stop_GPIO_Config();
	
	SHT85_IIC_InitStop();
	
	IIC_InitStop();
	
	USART_Stop_Config();
	
	initStopGPRS();
	
	USART_Stop_Config();	
}
//---------------end-------------------------
