#ifndef __PROCESS_MACHINE_H
#define __PROCESS_MACHINE_H

#include <stdint.h>

void resetAllState(void);

void ProcessNext(void);

void PrepareAnalyGpsData(void);
void PrepareAnalyCh4Data(void);
void PrepareSendGpsData(void);

void Init_Start(void);
void Init_Stop(void);

#endif	//__PROCESS_MACHINE_H
//---------end----------
