#ifndef __BSP_I2C_EE_H
#define	__BSP_I2C_EE_H

#include "stm32f10x.h"
#include "CompileConfig.h"

/* 
 * AT24C512 512kb = 512*1024bit = 512*1024/8 B = 64*1024 B = 64KB
 * 512 pages of 128 bytes each
 *
 * Device Address
 * 1 0 1 0 A2 A1 A0 R/W
 * 1 0 1 0 0  0  0  0 = 0XA0
 * 1 0 1 0 0  0  0  1 = 0XA1 
 */

/* EEPROM Addresses defines */


#ifdef USE_STM_IIC_FOR_EEPROM

void I2C_EE_Init(void);
void I2C_EE_BufferWrite(u8* pBuffer, u32 WriteAddr, u16 NumByteToWrite);
void I2C_EE_ByteWrite(u8* pBuffer, u16 WriteAddr);
void I2C_EE_PageWrite(u8* pBuffer, u16 WriteAddr, u8 NumByteToWrite);
void I2C_EE_BufferRead(u8* pBuffer, u32 ReadAddr, u16 NumByteToRead);
void I2C_EE_WaitEepromStandbyState(void);

void unlock_EEPROM_WP(void);
void lock_EEPROM_WP(void);

//ѡ��Ҫ������EEPROM�����ذ�������ƬEEPROM��
void EE_Select(uint8_t addr);

#endif

#endif /* __BSP_I2C_EE_H */
