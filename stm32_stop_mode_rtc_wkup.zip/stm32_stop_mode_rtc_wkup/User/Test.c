#include "CompileConfig.h"
#include "WatchDog.h"
#include "stm32f10x.h"
#include "delay.h"
#include "string.h"
#include "pcf8563.h"
#include "math.h"
#include "bsp_GPRS.h"
#include "math.h"
#include "DataManager.h"
#include "DataConfig.h"
#include "DataStructConfig.h"
#include "Test.h"
//-----------Private------------------

Trans_Data TestData1;
Trans_Data TestData2;
Trans_Data TestData3;
Trans_Data TestData4;
Trans_Data TestData5;


void TestUartInitData(void)
{
	TestData1.len = 10;
	TestData1.TxIndex = 0;
	memcpy(TestData1.data,"1010101010",10);
	
	TestData2.len = 10;
	TestData2.TxIndex = 0;
	memcpy(TestData2.data,"101010101",10);
	
	TestData3.len = 10;
	TestData3.TxIndex = 0;
	memcpy(TestData3.data,"101010101",10);
	
	TestData4.len = 10;
	TestData4.TxIndex = 0;
	memcpy(TestData4.data,"101010101",10);
	
	TestData5.len = 10;
	TestData5.TxIndex = 0;
	memcpy(TestData5.data,"101010101",10);
}
	
void TestUart1(void)
{
		if(TestData1.TxIndex >= TestData1.len)
		{
				USART_ClearFlag(USART1, USART_FLAG_TC);
				USART_ITConfig(USART1, USART_IT_TXE, DISABLE);       //���ж�
				TestData1.TxIndex = 0;
		}
		else
		{	
			
			while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
			USART_SendData(USART1,TestData1.data[TestData1.TxIndex++]);
		}
}

void TestUart2(void)
{
		if(TestData2.TxIndex >= TestData2.len)
		{
				USART_ClearFlag(USART2, USART_FLAG_TC);
				USART_ITConfig(USART2, USART_IT_TXE, DISABLE);       //���ж�
				TestData2.TxIndex = 0;
		}
		else
		{	
			while (USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET);
			USART_SendData(USART2,TestData2.data[TestData2.TxIndex++]);
		}
}

void TestUart3(void)
{
		if(TestData3.TxIndex >= TestData3.len)
		{
				USART_ClearFlag(USART3, USART_FLAG_TC);
				USART_ITConfig(USART3, USART_IT_TXE, DISABLE);       //���ж�
				TestData3.TxIndex = 0;
		}
		else
		{	
			
			while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
			USART_SendData(USART3,TestData3.data[TestData3.TxIndex++]);
		}
}

void TestUart4(void)
{
		if(TestData4.TxIndex >= TestData4.len)
		{
				USART_ClearFlag(UART4, USART_FLAG_TC);
				USART_ITConfig(UART4, USART_IT_TXE, DISABLE);       //���ж�
				TestData4.TxIndex = 0;
		}
		else
		{	
			
			while (USART_GetFlagStatus(UART4, USART_FLAG_TC) == RESET);
			USART_SendData(UART4,TestData4.data[TestData4.TxIndex++]);
		}
}

void TestUart5(void)
{
		if(TestData5.TxIndex >= TestData5.len)
		{
				USART_ClearFlag(UART5, USART_FLAG_TC);
				USART_ITConfig(UART5, USART_IT_TXE, DISABLE);       //���ж�
				TestData5.TxIndex = 0;
		}
		else
		{	
			
			while (USART_GetFlagStatus(UART5, USART_FLAG_TC) == RESET);
			USART_SendData(UART5,TestData5.data[TestData5.TxIndex++]);
		}
}

void TestUart1ENABLE(void)
{
	USART_ITConfig(USART1, USART_IT_TXE, ENABLE);       //ʹ�ܷ����ж�
}

void TestUart2ENABLE(void)
{
	USART_ITConfig(USART2, USART_IT_TXE, ENABLE);       //ʹ�ܷ����ж�
}

void TestUart3ENABLE(void)
{
	USART_ITConfig(USART3, USART_IT_TXE, ENABLE);       //ʹ�ܷ����ж�
}

void TestUart4ENABLE(void)
{
	USART_ITConfig(UART4, USART_IT_TXE, ENABLE);       //ʹ�ܷ����ж�
}

void TestUart5ENABLE(void)
{
	USART_ITConfig(UART5, USART_IT_TXE, ENABLE);       //ʹ�ܷ����ж�
}

Trans_Data Test_Reply_Data = {{0},0,0};
void AnalyTestData()
{
	int i;
	if(memcmp(Test_Reply_Data.data,"T",1) == 0)
	{
		i = 1;
	}
			
	Test_Reply_Data.TxIndex = 0;
	Test_Reply_Data.len = 0;
	memset(Test_Reply_Data.data,0,TRANS_DATA_MAX_SIZE);
}

void AddTestData(uint8_t ch)
{
#if 0
	if(Test_Reply_Data.TxIndex < 10)
	{
		Test_Reply_Data.data[Test_Reply_Data.TxIndex] = ch;
		Test_Reply_Data.TxIndex++;
	}else
	{
		Test_Reply_Data.TxIndex = 0;
		Test_Reply_Data.len = 0;
		memset(Test_Reply_Data.data,0,TRANS_DATA_MAX_SIZE);
	}

#else
	
	if(Test_Reply_Data.TxIndex < TRANS_DATA_MAX_SIZE)
	{
		Test_Reply_Data.data[Test_Reply_Data.TxIndex] = ch;
		Test_Reply_Data.TxIndex++;
	}
	
	if(ch == '\n')
	{
		AnalyTestData();
	}
#endif
}
//---------------end-------------------------
