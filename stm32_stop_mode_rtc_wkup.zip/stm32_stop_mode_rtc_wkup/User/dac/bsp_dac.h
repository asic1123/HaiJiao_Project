#ifndef __DAC_H
#define	__DAC_H


#include "stm32f10x.h"

void DAC_Mode_Init(void);


#endif /* __DAC_H */

