#ifndef __CHECKCODE_H
#define	__CHECKCODE_H

#include "stm32f10x.h"

enum RFID_MODE
{
	CARD_NULL,
	SEA_CARD_ERR,  //Ѱ������
	WRITE_CARD_ERR, //д������
	WRITE_CARD_SUCESS	//д���ɹ�
};

void sendNextRFIDCmdCh(void);
void AddRFIDReplyData(uint8_t ch);
void processRFIDTrans(void);

void processRFID(void);
void RFID_InitData(void);
void InitReplyData(void);

void InitRFID(void);

void TestRFID(void);
void SendUSART1_Data(void);
void sendNextRFIDTest(void);


#endif //__CHECKCODE_H
