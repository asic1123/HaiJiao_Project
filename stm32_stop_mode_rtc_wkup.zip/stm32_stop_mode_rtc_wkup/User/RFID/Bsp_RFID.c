#include "Bsp_RFID.h"
#include "string.h"
#include "DataStructConfig.h"
#include "CompileConfig.h"
#include "bsp_checkcode.h"
#include "DataConfig.h"
#include "delay.h"
#include "bsp_gpio.h"

#define RFID_USART UART5
#define RFID_USART_Test USART3

uint8_t m_RFIDHeadData[3];
uint8_t m_RFIDCmdPackType = 0;
uint8_t m_RFIDblock = 0;
uint8_t m_RFID_State = CARD_NULL;
extern uint16_t EEP_dataCount;

Trans_Data RFID_Cmd_Data;
Trans_Data RFID_Reply_Data;
Trans_Data RFID_GPRS_Data;

uint8_t RFIDErrorCode = 0;
int i = 0;
char PassWord[4] = {0x00,0x00,0x00,0x00};

char TestData[8] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};

void RFIDGPRSTest()
{
	memset(RFID_GPRS_Data.data,0,TRANS_DATA_MAX_SIZE);
	memcpy(RFID_GPRS_Data.data,RFID_Reply_Data.data,RFID_Reply_Data.len);
	RFID_GPRS_Data.len = RFID_Reply_Data.len;
	RFID_GPRS_Data.TxIndex = 0;
	USART_ITConfig(RFID_USART_Test, USART_IT_TXE, ENABLE); 
}

void RFID_Send_Data(uint8_t* data,uint32_t size)
{
	memset(RFID_Cmd_Data.data,0,TRANS_DATA_MAX_SIZE);
	memcpy(RFID_Cmd_Data.data,data,size);
	RFID_Cmd_Data.TxIndex = 0;
	RFID_Cmd_Data.len = size;
	
	USART_ITConfig(RFID_USART, USART_IT_TXE, ENABLE); 
}

void RFID_WriteData()
{
	
}

void InitReplyData(void)
{
	memset(RFID_Reply_Data.data,0,TRANS_DATA_MAX_SIZE);
	RFID_Reply_Data.TxIndex = 0;
	RFID_Reply_Data.len = 0;
	memset(m_RFIDHeadData,0,3);
	m_RFIDCmdPackType = 0x00;
}

void RFID_InitData(void)
{
	InitReplyData();
	memset(m_RFIDHeadData,0,3);
}
	
void RFID_Reset(void)
{
	unsigned char checkcode;
	
	InitReplyData();
	
	RFID_Reply_Data.data[0] = 0xA0;
	RFID_Reply_Data.data[1] = 0x03;
	RFID_Reply_Data.data[2] = 0xFF;
	RFID_Reply_Data.data[3] = 0x70;
	
	checkcode = CheckSum(RFID_Reply_Data.data, 4);
	
	RFID_Reply_Data.data[4] = checkcode;
}

void RFID_SetBaudrate(void)
{
	unsigned char checkcode;
	
	InitReplyData();
	
	RFID_Reply_Data.data[0] = 0xA0;
	RFID_Reply_Data.data[1] = 0x04;
	RFID_Reply_Data.data[2] = 0xFF;
	RFID_Reply_Data.data[3] = 0x71;
	RFID_Reply_Data.data[4] = 0x04; //���ò�����Ϊ115200
	
	checkcode = CheckSum(RFID_Reply_Data.data, 5);
	
	RFID_Reply_Data.data[5] = checkcode;
}

void RFID_SetReaderAddress(uint8_t Address)
{
	unsigned char checkcode;
	
	InitReplyData();
	
	RFID_Reply_Data.data[0] = 0xA0;
	RFID_Reply_Data.data[1] = 0x04;
	RFID_Reply_Data.data[2] = 0xFF;
	RFID_Reply_Data.data[3] = 0x73;
	RFID_Reply_Data.data[4] = Address; 
	
	checkcode = CheckSum(RFID_Reply_Data.data, 5);
	
	RFID_Reply_Data.data[5] = checkcode;		
}

void RFID_SetOutputPower(void)
{
	unsigned char checkcode;
	
	InitReplyData();
	
	RFID_Reply_Data.data[0] = 0xA0;
	RFID_Reply_Data.data[1] = 0x04;
	RFID_Reply_Data.data[2] = 0xFF;
	RFID_Reply_Data.data[3] = 0x76;
	RFID_Reply_Data.data[4] = 0x12; //26dBm0x1A ���18 0x12
	
	checkcode = CheckSum(RFID_Reply_Data.data, 5);
	
	RFID_Reply_Data.data[5] = checkcode;	
}

void RFID_GetOutputPower(void)
{
	unsigned char checkcode;
	
	InitReplyData();
	
	RFID_Reply_Data.data[0] = 0xA0;
	RFID_Reply_Data.data[1] = 0x03;
	RFID_Reply_Data.data[2] = 0xFF;
	RFID_Reply_Data.data[3] = 0x77;
	
	checkcode = CheckSum(RFID_Reply_Data.data, 4);
	
	RFID_Reply_Data.data[4] = checkcode;	
}

void RFID_Inventory(void)
{
	unsigned char checkcode;
	
	InitReplyData();
	
	RFID_Reply_Data.data[0] = 0xA0;
	RFID_Reply_Data.data[1] = 0x04;
	RFID_Reply_Data.data[2] = 0xFF;
	RFID_Reply_Data.data[3] = 0x80;
	RFID_Reply_Data.data[4] = 0xFF; 
	
	checkcode = CheckSum(RFID_Reply_Data.data, 5);
	
	RFID_Reply_Data.data[5] = checkcode;
}

void RFID_Lock(void)
{
	unsigned char checkcode;
	
	InitReplyData();
	
	RFID_Reply_Data.data[0] = 0xA0;
	RFID_Reply_Data.data[1] = 0x09;
	RFID_Reply_Data.data[2] = 0xFF;
	RFID_Reply_Data.data[3] = 0x83;
	
	memcpy(RFID_Reply_Data.data+4,PassWord,4);
	
	RFID_Reply_Data.data[8] = 0x01;
	RFID_Reply_Data.data[9] = 0x00;
	
	checkcode = CheckSum(RFID_Reply_Data.data, 10);
	
	RFID_Reply_Data.data[10] = checkcode;
}

//void RFID_ReadCard(uint8_t Address,uint8_t WordAdd)
void RFID_ReadCard()
{
	unsigned char checkcode;
	
	InitReplyData();
	
	RFID_Reply_Data.data[0] = 0xA0;
	RFID_Reply_Data.data[1] = 0x0A;
	RFID_Reply_Data.data[2] = 0x01;
	RFID_Reply_Data.data[3] = 0x81;
	RFID_Reply_Data.data[4] = 0x03; //0x00:RESERVED 0x01:EPC 0x02:TID 0x03:USER
	
	RFID_Reply_Data.data[5] = 0x00;
	
	RFID_Reply_Data.data[6] = 0x08;
	
	memcpy(RFID_Reply_Data.data+7,PassWord,4);
	
	checkcode = CheckSum(RFID_Reply_Data.data, 11);
	
	RFID_Reply_Data.data[11] = checkcode;
}

//void RFID_WriteCard(uint8_t Address, uint8_t WordAdd,uint8_t *_pWriteBuf,uint16_t _usSize)
void RFID_WriteCard()
{
	unsigned char checkcode;
	
	InitReplyData();
	
	RFID_Reply_Data.data[0] = 0xA0;
	RFID_Reply_Data.data[1] = 0x0A+8;
	RFID_Reply_Data.data[2] = 0x01;
	RFID_Reply_Data.data[3] = 0x82;
	
	memcpy(RFID_Reply_Data.data+4,PassWord,4);
	
	RFID_Reply_Data.data[8] = 0x03; //0x00:RESERVED 0x01:EPC 0x02:TID 0x03:USER
	
	RFID_Reply_Data.data[9] = 0x00;
	
	RFID_Reply_Data.data[10] = 0x04; //���ȴ���8���ֽ�
	
			
	//memcpy(RFID_Reply_Data.data+9,_pWriteBuf,_usSize);
	
//	RFID_Reply_Data.data[1] = 0x09+_usSize;
//	
//	checkcode = CheckSum(&RFID_Reply_Data.data, 0x09+_usSize);
//	
//	RFID_Reply_Data.data[0x09+_usSize+1] = checkcode;
	
	memcpy(RFID_Reply_Data.data+11,TestData,8);	//����ʹ��
	
	checkcode = CheckSum(RFID_Reply_Data.data, 0x0B+8);
	RFID_Reply_Data.data[0x0B+8] = checkcode;
	
}

void sendNextRFIDCmdCh(void)
{
	if( RFID_Cmd_Data.TxIndex >= RFID_Cmd_Data.len )//TC��Ҫ ��SR+дDR ������0,�����͵����,��'\0'��ʱ���ø�if�жϹص�
	{
		RFID_Cmd_Data.len  = 0;
		USART_ClearFlag(RFID_USART, USART_FLAG_TC);//��ȻTCһֱ��set, TCIEҲ�Ǵ򿪵�,���»᲻ͣ�����ж�. clear������,���ùص�TCIE
		USART_ITConfig(RFID_USART, USART_IT_TXE, DISABLE);
	}
	else
	{
		USART_SendData(RFID_USART, RFID_Cmd_Data.data[RFID_Cmd_Data.TxIndex]);
		RFID_Cmd_Data.TxIndex++;
	}
}

void sendNextRFIDTest(void)
{
	if( RFID_GPRS_Data.TxIndex >= RFID_GPRS_Data.len )//TC��Ҫ ��SR+дDR ������0,�����͵����,��'\0'��ʱ���ø�if�жϹص�
	{
		RFID_GPRS_Data.len  = 0;
		USART_ClearFlag(RFID_USART_Test, USART_FLAG_TC);//��ȻTCһֱ��set, TCIEҲ�Ǵ򿪵�,���»᲻ͣ�����ж�. clear������,���ùص�TCIE
		USART_ITConfig(RFID_USART_Test, USART_IT_TXE, DISABLE);
	}
	else
	{
		USART_SendData(RFID_USART_Test, RFID_GPRS_Data.data[RFID_GPRS_Data.TxIndex]);
		RFID_GPRS_Data.TxIndex++;
	}
}

void AddRFIDReplyData(uint8_t ch)
{
	if(RFID_Reply_Data.len > 0)
	{
		if(RFID_Reply_Data.TxIndex < RFID_Reply_Data.len)
		{
			RFID_Reply_Data.data[RFID_Reply_Data.TxIndex] = ch;
			RFID_Reply_Data.TxIndex++;			
		}
	}
	else
	{
		m_RFIDHeadData[0] = ch;
		RFID_Reply_Data.len = m_RFIDHeadData[0];
	}
}
extern uint8_t needSendGPRSDataTest;
void processRFID(void)
{
	if(RFID_Reply_Data.len >0 && RFID_Reply_Data.TxIndex >= RFID_Reply_Data.len)
	{
		switch(RFID_Reply_Data.data[1])
		{
		
			case 0x70: 	//��λ
				InitReplyData();
				break;
			case 0x71:	//���ò�����
				RFIDErrorCode = RFID_Reply_Data.data[2];
				InitReplyData();
				break;
			case 0x76: //����RF�������
				InitReplyData();
				break;
			case 0x77: //��ȡRF�������
				RFIDGPRSTest();
				InitReplyData();
				break;
			case 0x80:  //�̴��ǩ�������ǩ������
				InitReplyData();
				break;
			case 0x81:	//����ǩ
				RFIDGPRSTest();
				//needSendGPRSDataTest = 1;
				InitReplyData();
				break;
			case 0x82:	//д��ǩ
				InitReplyData();
				break;
			case 0x83: //lock
				InitReplyData();
				break;
			default:
				break;
		}
	}
}

extern uint8_t needSendGPRSDataTest;
void TestRFID(void)
{
	if(i > 400000 && i < 400002)
	{
		i++;
		RFID_ReadCard(); //12
		RFID_Send_Data(RFID_Reply_Data.data,12);
	}else if(i > 600000)
	{
		i = 0;
		RFID_WriteCard();
		RFID_Send_Data(RFID_Reply_Data.data,20);
		
	}else
	{
		i++;
	}
}

void InitRFID(void)
{
	SWITCH_RFID(ON);
	delay_ms(50);
	SWITCH_RFIDWORK(ON);
	delay_ms(50);
	RFID_SetOutputPower();//6
	RFID_Send_Data(RFID_Reply_Data.data,6);
	delay_ms(50);
//	RFID_GetOutputPower();
//	RFID_Send_Data(RFID_Reply_Data.data,5);
	delay_ms(50);
}
