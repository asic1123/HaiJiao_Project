#ifndef __CHECKCODE_H
#define	__CHECKCODE_H

#include "stm32f10x.h"

void collating_data(u8 *data, u32 len);
u8 check_data(u8* data, u32 len);

u16 calc_sum(void *data, u32 len);
u16 calc_xor(void *data, u32 len);

unsigned char  CheckSum(unsigned char *uBuff, unsigned char uBuffLen); //RFIDУ���

#endif //__CHECKCODE_H
