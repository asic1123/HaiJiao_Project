//#include "GobalDefine.h"
#include "CompileConfig.h"
#include "WatchDog.h"
#include "stm32f10x.h"

#define WATCH_DOG_IO		GPIOC
#define WATCH_DOG_PIN		GPIO_Pin_0

void initWatchDog(void)
{

}

void feedWatchDog(void)
{

}
//---------------end-------------------------
