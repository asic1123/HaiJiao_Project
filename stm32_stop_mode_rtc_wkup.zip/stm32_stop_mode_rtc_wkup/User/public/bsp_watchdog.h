#ifndef __BSP_WATCH_DOG_H
#define	__BSP_WATCH_DOG_H

#include "stm32f10x.h"

void watchdog_config(void);
void feed_watchdog(void);
void needResetSystem(void);

#endif /* __BSP_WATCH_DOG_H */
