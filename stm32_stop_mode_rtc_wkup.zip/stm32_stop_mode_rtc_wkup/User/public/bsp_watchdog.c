/**
  ******************************************************************************
  *
  ******************************************************************************
  */
  
#include "bsp_watchdog.h"

u8 g_NeedReset = 0;

void IWDG_Config(void)
{
   IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);

   IWDG_SetPrescaler(IWDG_Prescaler_64);  //40K/64 = 625Hz,һ�μ����ʱ1/625

   IWDG_SetReload(625); //625*(1/625) = 1s

   IWDG_ReloadCounter();

   IWDG_Enable();
}

void WWDG_Config(void)
{
	
}

 /**
  * @brief  ��ʼ������
  * @param  ��
  * @retval ��
  */
void watchdog_config(void)
{
	g_NeedReset = 0;
	IWDG_Config();
}

void feed_watchdog(void)
{
	if(g_NeedReset == 0)
		IWDG_ReloadCounter();
}

void needResetSystem(void)
{
	g_NeedReset = 1;
}

/*********************************************END OF FILE**********************/
