#ifndef __WATCH_DOG_H
#define __WATCH_DOG_H

#include <stdint.h>
#include "CompileConfig.h"

void initWatchDog(void);

void feedWatchDog(void);

#endif	//__PUBLIC_FUN_H
//---------end----------
