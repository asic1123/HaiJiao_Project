#ifndef __TASK_LIST_H
#define	__TASK_LIST_H

#include "stm32f10x.h"

void sampleFinished(void);
void runTask(void);

#endif /* __TASK_LIST_H */
