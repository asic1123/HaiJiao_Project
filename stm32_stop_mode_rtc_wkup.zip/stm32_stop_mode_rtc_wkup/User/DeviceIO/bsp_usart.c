/**
  ******************************************************************************
  * @file    bsp_usart1.c
  * @author  Eason
  * @version V1.0
  * @date    2014-xx-xx
  * @brief   ����c��printf������usart�˿�
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:Ұ�� ISO-MINI STM32 ������ 
  *
  ******************************************************************************
  */ 
  
#include "bsp_usart.h"

void USART_NVIC_Config(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	
	//�����ж�
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;         //���ô���1�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;         //��ռ���ȼ� 1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;    //�����ȼ�Ϊ1
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;     //ʹ��
	NVIC_Init(&NVIC_InitStructure);
	delay_ms(100);
	
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;         //���ô���2�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;         //��ռ���ȼ� 1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;    //�����ȼ�Ϊ2
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;     //ʹ��
	NVIC_Init(&NVIC_InitStructure);
	delay_ms(100);
	
	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;         //���ô���3�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;         //��ռ���ȼ� 1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;    //�����ȼ�Ϊ3
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;     //ʹ��
	NVIC_Init(&NVIC_InitStructure);
	delay_ms(100);
	
	NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;         //���ô���4�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;         //��ռ���ȼ� 1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 4;    //�����ȼ�Ϊ4
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;     //ʹ��
	NVIC_Init(&NVIC_InitStructure);
	delay_ms(100);
	
	NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn;         //���ô���4�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;         //��ռ���ȼ� 1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 5;    //�����ȼ�Ϊ4
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;     //ʹ��
	NVIC_Init(&NVIC_InitStructure);
	delay_ms(100);
}

 /**
  * @brief  USART1 GPIO ����,����ģʽ���á�115200 8-N-1
  * @param  ��
  * @retval ��
  */
void USART1_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
		
	/* config USART1 clock */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
		
	/* USART1 GPIO config */
	/* Configure USART1 Tx (PA.09) as alternate function push-pull */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);    
	/* Configure USART1 Rx (PA.10) as input floating */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
			
	/* USART1 mode config */
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No ;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART1, &USART_InitStructure);
		
	USART_ClearFlag(USART1,USART_FLAG_TC);         //���������ɱ�־λ	
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);       //ʹ�ܽ����ж� 
	USART_Cmd(USART1, ENABLE);
}

void USART4_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
		
	USART_DeInit(UART4);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, ENABLE);
	/* config USART3 clock */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);
			
	/* USART2 GPIO config */
	/* Configure USART2 Tx (PA.02) as alternate function push-pull */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);    
	/* Configure USART2 Rx (PA.03) as input floating */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
			
	/* USART2 mode config */
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No ;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(UART4, &USART_InitStructure);
	
	USART_ClearFlag(UART4,USART_FLAG_TC);         //���������ɱ�־λ	
	USART_ITConfig(UART4, USART_IT_RXNE, ENABLE);       //ʹ�ܽ����ж�
		 
	USART_Cmd(UART4, ENABLE);	
				
}

void USART2_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
		
	USART_DeInit(USART2);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
	/* config USART3 clock */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
			
	/* USART2 GPIO config */
	/* Configure USART2 Tx (PA.02) as alternate function push-pull */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);    
	/* Configure USART2 Rx (PA.03) as input floating */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
			
	/* USART2 mode config */
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No ;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART2, &USART_InitStructure);
	
	USART_ClearFlag(USART2,USART_FLAG_TC);         //���������ɱ�־λ	
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);       //ʹ�ܽ����ж�
		 
	USART_Cmd(USART2, ENABLE);					
}

void USART3_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
		
	USART_DeInit(USART3);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_AFIO, ENABLE);
	/* config USART3 clock */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
	
	GPIO_PinRemapConfig(GPIO_FullRemap_USART3,ENABLE);
			
	/* USART2 GPIO config */
	/* Configure USART2 Tx (PA.02) as alternate function push-pull */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOD, &GPIO_InitStructure);    
	/* Configure USART2 Rx (PA.03) as input floating */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
			
	/* USART2 mode config */
	USART_InitStructure.USART_BaudRate = 4800;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No ;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART3, &USART_InitStructure);
	
	USART_ClearFlag(USART3,USART_FLAG_TC);         //���������ɱ�־λ	
	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);       //ʹ�ܽ����ж�
		 
	USART_Cmd(USART3, ENABLE);	
				
}

void USART5_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
		
	USART_DeInit(UART5);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC |RCC_APB2Periph_GPIOD | RCC_APB2Periph_AFIO, ENABLE);
	/* config USART3 clock */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, ENABLE);
			
	/* USART2 GPIO config */
	/* Configure USART2 Tx (PA.02) as alternate function push-pull */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);    
	/* Configure USART2 Rx (PA.03) as input floating */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
			
	/* USART2 mode config */
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No ;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(UART5, &USART_InitStructure);
	
	USART_ClearFlag(UART5,USART_FLAG_TC);         //���������ɱ�־λ	
	USART_ITConfig(UART5, USART_IT_RXNE, ENABLE);       //ʹ�ܽ����ж�
		 
	USART_Cmd(UART5, ENABLE);	
				
}

void USART_Config(void)
{
	USART_NVIC_Config();
	USART1_Config();
	USART2_Config();
	USART3_Config();
	USART4_Config();
	USART5_Config();
}

void USART_Stop_Config(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	
	//�����ж�
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;         //���ô���1�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;         //��ռ���ȼ� 1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;    //�����ȼ�Ϊ1
	NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;     //ʹ��
	NVIC_Init(&NVIC_InitStructure);
	delay_ms(100);
	
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;         //���ô���2�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;         //��ռ���ȼ� 1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;    //�����ȼ�Ϊ2
	NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;     //ʹ��
	NVIC_Init(&NVIC_InitStructure);
	delay_ms(100);
	
	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;         //���ô���3�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;         //��ռ���ȼ� 1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;    //�����ȼ�Ϊ3
	NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;     //ʹ��
	NVIC_Init(&NVIC_InitStructure);
	delay_ms(100);
	
	NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;         //���ô���4�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;         //��ռ���ȼ� 1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 4;    //�����ȼ�Ϊ4
	NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;     //ʹ��
	NVIC_Init(&NVIC_InitStructure);
	delay_ms(100);
	
	NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn;         //���ô���4�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;         //��ռ���ȼ� 1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 5;    //�����ȼ�Ϊ4
	NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;     //ʹ��
	NVIC_Init(&NVIC_InitStructure);
	delay_ms(100);

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,DISABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, DISABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, DISABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, DISABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, DISABLE);
//	USART_ITConfig(UART5, USART_IT_RXNE, DISABLE);       //ʹ�ܽ����ж�
//	USART_ITConfig(UART5, USART_IT_TXE, DISABLE);       //ʹ�ܽ����ж�
}
/*********************************************END OF FILE**********************/
