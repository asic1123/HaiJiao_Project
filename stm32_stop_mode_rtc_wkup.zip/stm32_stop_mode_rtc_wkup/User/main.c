/******************** (C) COPYRIGHT 2008 STMicroelectronics ********************
* File Name          : main.c
* Author             : Eason
* Version            : 20160328
* Date               : 2015/6/10
* Description        : Main program body
********************************************************************************
*
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "bsp_rtc.h"
#include "rtc.h"
#include "delay.h"
#include "wkup.h"
#include "bsp_usart.h"
#include "stm32f10x_pwr.h"

/*******************************************************************************
* Function Name  : main
* Description    : Main program
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

int main(void)
{

	RTC_CheckAndConfig();
	
//	WKUP_Init(); //�������ѳ�ʼ��	
	
//	USART_Config();

	while(1)
	{
		
#if 1 //���ڲ�������������

//		TestUart4ENABLE();
		delay_ms(1000);
		delay_ms(1000);
		delay_ms(1000);
		delay_ms(1000);
		delay_ms(1000);



#endif
		
//		RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR , ENABLE);
//		PWR_EnterSTOPMode(PWR_Regulator_LowPower, PWR_STOPEntry_WFE); 

		WKUP_Init(); 
		SystemInit();
		
		
	}
}
