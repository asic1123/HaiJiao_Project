#ifndef __BSP_GPRS_H
#define	__BSP_GPRS_H

#include "CompileConfig.h"
#include "stm32f10x.h"
#include <stdio.h>

enum GPRS_CMD{
	UCMD_GPRS = 0,
	CMD_GPRS_CHECK,
	CMD_GPRS_INIT,
	CMD_GPRS_CSQ,
	CMD_GPRS_CIPMODE,
	CMD_GPRS_NETSTART,
	CMD_GPRS_CONNECT,	
	CMD_GPRS_BYTEWRITE,
	CMD_GPRS_DATATX,	
	CMD_GPRS_NETCLOSE,
	CMD_GPRS_RESET,
	CMD_GPRS_START    //++slj 15-9-19
};

void initGPRS(void);
void initStopGPRS(void);

void InitGprsData(void);
void AddGprsReplyData(uint8_t ch);
void AnalyGprsData(void);

void GPRS_Check(void);
void GPRS_Init(void);
void GPRS_CSQ_Signal(void);
void GPRS_CipMode(void);
void GPRS_Start_Network(void);
void GPRS_Connect(void);
void GPRS_WriteData(u8* data,uint32_t size);
void GPRS_TxData(void);
void GPRS_Send_Data(char* data,uint32_t size);
void GPRS_Reset(void);
//++slj 15-9-19
void GPRS_Start(void);

void sendNextGprsCmdCh(void);

uint8_t getLastGprsCmd(void);
uint8_t getLastGprsCmdState(void);

uint8_t gprsIsConnected(void);

void initGprsTrans(void);

uint8_t tryToConnectGprs(void);
uint8_t tryToSendGprsData(void);

#endif /* __BSP_GPRS_H */
