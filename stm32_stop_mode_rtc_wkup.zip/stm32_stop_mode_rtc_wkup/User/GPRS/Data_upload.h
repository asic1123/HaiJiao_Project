#ifndef __DATA_UPLOAD_H
#define __DATA_UPLOAD_H

#include <stdint.h>
//#include "sys.h"
#include "delay.h"
#include "CompileConfig.h"

#define UPLOAD_GPS_DATA 0x01
#define UPLOAD_WELD_DATA 0x02
#define UPLOAD_WELDNO_DATA 0x03
#define UPLOAD_FITTING_DATA 0x04
#define UPLOAD_ATTENDANCE_DATA 0x05
#define UPLOAD_TEST_DATA	0x06

#define GPRS_DATA_MAX_SIZE 1050 //1050

#define GPRS_PHOTO_READ_LEN  1024 //1024

struct uploadDataStruct
{
	uint8_t data[GPRS_DATA_MAX_SIZE];
	uint16_t len;
};

extern struct uploadDataStruct uploadData;

uint8_t curUploadDataType(void);
int curUploadDataIndex(void);		//��ǰ�ϴ��ĺ������ݱ�ţ���0��ʼ����

uint8_t initDataUpload(uint8_t type,int index);
void startDataUpload(void);
uint8_t processDataUpload(void);

#endif	//__DATA_UPLOAD_H
