#include "bsp_GPRS.h"
#include "CompileConfig.h"
#include <string.h>
#include <stdlib.h>
#include "DataStructConfig.h"
#include "stm32f10x.h"
#include "Data_upload.h"
//#include "w25qxx.h"
#include "delay.h"
//#include "SheepData.h"
//#include "LogInfo.h"
//#include "ff.h"
//#include "malloc.h"
#include "ParaManager.h"
//#include "DataManager.h"
#include "PublicFunc.h"
//#include "Page07.h"
//#include "IdentState.h"
#include "stdio.h"
#include "bsp_gpio.h"


#include "check_4G_SIM.h"

#define GPRS_RESET_PIN GPIO_Pin_7
#define GPRS_RESET_IO GPIOD
#define GPRS_USART USART2


#define WAIT_CMD_SPACE //�����������


uint8_t m_gprsIsRight = 0; 

Trans_Data GPRS_CMD_Data;

Trans_Data GPRS_Reply_Data = {{0},0,0};

extern char FacePathData[100];
uint8_t gprsLastCmd = UCMD_GPRS;

uint8_t lastGprsCmdState = 0;	//0:hold 1:succeed 2:fail


u16 isRetryGPRS = 0; //�ط�����
u8 gprsCmdErrCount = 0; //gprs����ִ�д������
uint32_t gprsTimeOutCounter = 0;
u8 m_gprsIsConnected = 0;
//char *server_info = "\"test.shhydrau.com\",10002\r\n";
//char *server_info = "\"124.205.51.162\",10000\r\n"; //����������
//char *server_info = "\"203.156.196.43\",10000\r\n"; //���Է�����
//char *server_info ="\"222.73.218.120\",10000\r\n"; //�Ϻ�������
//#if DATA_UPLOAD_PROTOCOL_TYPE == 0
//char *server_info ="\"116.236.147.82\",10000\r\n"; //�Ϻ�������
//#elif DATA_UPLOAD_PROTOCOL_TYPE == 1
//char *server_info ="\"116.236.147.82\",10002\r\n"; //�Ϻ�������
//#elif  DATA_UPLOAD_PROTOCOL_TYPE == 2
//char *server_info ="\"58.248.3.172\",10081\r\n"; //���ݷ�����
//#endif

//char *server_info ="\"180.167.43.62\",10002\r\n"; //����ʹ�÷�����
char server_info[32]= {"\"180.167.43.62\",10002\r\n"};//����ʹ��

u8 signal_grade = 0; //�źŵȼ�

u8 timeoutCount = 0; //++slj ���ݴ��䳬ʱ����������һ����������λ�������᲻�ᵼ�·��������յ����ͬ���İ���


//#ifdef WAIT_CMD_SPACE
u32 cmd_space = 0;
u8 waitCmdSpace(u32 space)
{
	if(cmd_space < space)
	{
		cmd_space++;
	}
	else
	{
		cmd_space = 0;
		return 1;
	}
	
	return 0;
}
//#endif

//--------------------------------Pub--------------------------
void GPRS_GPIO_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOC, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPRS_RESET_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPRS_RESET_IO, &GPIO_InitStructure);  	
	
	SWITCH_GPRS(ON);
	delay_ms(50);
	
	SWITCH_GPRSWORK(ON);
	GPIO_ResetBits(GPRS_RESET_IO,GPRS_RESET_PIN);//GPRS_RESET_PIN���õ�	
}

void initGPRS(void)
{ 
	char tmpStr[32] = {0};
	char tmpStr2[32] = {0};
	
	GPRS_GPIO_Init();

	GPRS_Reset();	
	
//	sprintf(tmpStr,"%.*s",15,SysConfPara.GPRS_IP);
//	removeLastReg(tmpStr,'-');	
//	sprintf(tmpStr2,"\"%s\"",tmpStr);
//	
//	sprintf(tmpStr,"%.*s",6,SysConfPara.GPRS_Port);
//	removeLastReg(tmpStr,'-');	
//	sprintf(server_info,"%s,%s\r\n",tmpStr2,tmpStr);
}

void initStopGPRS(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOC, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPRS_RESET_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPRS_RESET_IO, &GPIO_InitStructure);  	
}
///////////////////////////////////////////////////////
	
void InitGprsReplyData(void)
{
	memset(GPRS_Reply_Data.data,0,TRANS_DATA_MAX_SIZE);
	GPRS_Reply_Data.TxIndex = 0;
	GPRS_Reply_Data.len = 0;
}

void GPRS_Prefer_mode_select(void)
{
	char tmp[8] = {0};

	char gprs_cmd[50] = "AT+CNMP=";

	sprintf(tmp,"%d\r\n",1);
	strcat(gprs_cmd,tmp);
	
	GPRS_Send_Data(gprs_cmd,strlen(gprs_cmd));	
}

//++slj 15-9-19
void GPRS_Start(void)
{
	gprsLastCmd = CMD_GPRS_START;
	InitGprsReplyData();
	
	lastGprsCmdState = 1;
}
	
void GPRS_Check(void)
{
	char *gprs_cmd = "at+csockauth=1,0\r\n";
	gprsLastCmd = CMD_GPRS_CHECK;
	InitGprsReplyData();	
		
	GPRS_Send_Data(gprs_cmd,strlen(gprs_cmd));	
	
}

void GPRS_Init(void)
{
	char *gprs_cmd = "AT+CFUN=1\r\n";
	gprsLastCmd = CMD_GPRS_INIT;
	InitGprsReplyData();	
	
	GPRS_Send_Data(gprs_cmd,strlen(gprs_cmd));
}

void GPRS_CSQ_Signal(void)
{
	char *gprs_cmd = "AT+CSQ\r\n";
	gprsLastCmd = CMD_GPRS_CSQ;
	InitGprsReplyData();
	GPRS_Send_Data(gprs_cmd,strlen(gprs_cmd));	
}

void GPRS_CipMode(void)
{
	char *gprs_cmd = "at+cipmode=1\r\n";
	gprsLastCmd = CMD_GPRS_CIPMODE;
	InitGprsReplyData();
	GPRS_Send_Data(gprs_cmd,strlen(gprs_cmd));
	
}
void GPRS_Start_Network(void)
{
	char *gprs_cmd = "at+netopen\r\n";

	gprsLastCmd = CMD_GPRS_NETSTART;
	InitGprsReplyData();	
	GPRS_Send_Data(gprs_cmd,strlen(gprs_cmd));		
	
}
void GPRS_Connect(void)
{
	char gprs_cmd[50] = "AT+CIPOPEN=0,\"TCP\",";

	strcat(gprs_cmd,server_info);	
	
	gprsLastCmd = CMD_GPRS_CONNECT;
	InitGprsReplyData();	
	GPRS_Send_Data(gprs_cmd,strlen(gprs_cmd));	
	
}
void GPRS_WriteData(u8* data,uint32_t size)
{
	gprsLastCmd = CMD_GPRS_BYTEWRITE;
//	memcpy(txData,data,size);
//	txData_Len = size;
}

void GPRS_TxData(void)
{
	gprsLastCmd = CMD_GPRS_DATATX;
	InitGprsReplyData();
	
//	GPRS_Send_Data(txData,txData_Len);
	//GPRS_Send_Data(txData,strlen(txData));
	
	GPRS_Send_Data(uploadData.data,uploadData.len);
}
	
void GPRS_Send_Data(char* data,uint32_t size)
{
	memset(GPRS_CMD_Data.data,0,GPRS_DATA_MAX_SIZE);
	memcpy(GPRS_CMD_Data.data,data,size);
	GPRS_CMD_Data.TxIndex = 0;
	GPRS_CMD_Data.len = size;
	lastGprsCmdState = 0;
	
	//delay_ms(1000); //ÿ������֮�����Ӽ�������������ʧ��
	
	USART_ITConfig(GPRS_USART, USART_IT_TXE, ENABLE);

}
void AddGprsReplyData(uint8_t ch)
{
	if(GPRS_Reply_Data.TxIndex < TRANS_DATA_MAX_SIZE)
	{
		GPRS_Reply_Data.data[GPRS_Reply_Data.TxIndex] = ch;
		GPRS_Reply_Data.TxIndex++;
	}

	if(gprsLastCmd == CMD_GPRS_DATATX)
	{
		if(GPRS_Reply_Data.TxIndex == 2)
		{
			AnalyGprsData();
		}
	}
	else
	{
//		if(GPRS_Reply_Data.TxIndex >= 21)
//			AnalyGprsData();
		if(ch == '\n')
		{
			AnalyGprsData();
		}
	}
}

void AnalyGprsData(void)
{
	char tmp[8];
	if(gprsLastCmd == CMD_GPRS_DATATX)
	{
		if(GPRS_Reply_Data.data[0] == 0x00 && GPRS_Reply_Data.data[1] == 0x01)
		{
			lastGprsCmdState = 2;
		
		}
		else if(GPRS_Reply_Data.data[0] == 0x00 && GPRS_Reply_Data.data[1] == 0x02)
		{
			lastGprsCmdState = 2;
			
		}
		else if(GPRS_Reply_Data.data[0] == 0x00 && GPRS_Reply_Data.data[1] == 0x03)
		{
			lastGprsCmdState = 3;
		
		}
		else if(GPRS_Reply_Data.data[0] == 0x00 && GPRS_Reply_Data.data[1] == 0x00)
		{

			lastGprsCmdState = 1;
		}
		else
		{
			lastGprsCmdState = 2;
		}
	}
	else
	{
		if(gprsLastCmd == CMD_GPRS_CSQ && lastGprsCmdState != 0) 
		{
			InitGprsReplyData();
			return;
		}

		if(gprsLastCmd == CMD_GPRS_NETSTART)
		{
			if(memcmp(GPRS_Reply_Data.data,"+NETOPEN: 0",11) == 0)
			{
				lastGprsCmdState = 1;
			}
			else if(memcmp(GPRS_Reply_Data.data,"+NETOPEN: 1",11) == 0)
			{
				lastGprsCmdState = 2;
			}
			else if(memcmp(GPRS_Reply_Data.data,"ERROR",5) == 0)
				lastGprsCmdState = 2;
		}
		else
		
		if(memcmp(GPRS_Reply_Data.data,"OK",2) == 0)
		{
			lastGprsCmdState = 1;
		}

		//��ʽ +CSQ: 3,99 +CSQ: 18,99 +CSQ: 20,0 +CSQ: 3,0 +CSQ: 150,0
		else if(memcmp(GPRS_Reply_Data.data,"+CSQ",4) == 0)
		{
			signal_grade = GPRS_Reply_Data.data[6]-'0';			
			if(GPRS_Reply_Data.data[7] != ',')
			{
				signal_grade = signal_grade*10 + (GPRS_Reply_Data.data[7]-'0');
				if(GPRS_Reply_Data.data[8] != ',')
					signal_grade = signal_grade*10 + (GPRS_Reply_Data.data[8]-'0');
			}
					
//			if(isExistSIM() == 0)
//				signal_grade = 0;
		
			if(signal_grade >= 100)
				signal_grade = (signal_grade%100)/3;
			
			if(signal_grade > 32 && signal_grade!=99)
				signal_grade = 32;
			
			if(signal_grade < 2 || signal_grade==99)
			{
				lastGprsCmdState = 2;
			}
			else
			{
				lastGprsCmdState = 1;
			}
		}

		else if(memcmp(GPRS_Reply_Data.data,"ERROR",5) == 0)
		{
			lastGprsCmdState = 2;
		}
		else if(memcmp(GPRS_Reply_Data.data,"CLOSED",6) == 0)
		{
			lastGprsCmdState = 3;
		}
		else if(memcmp(GPRS_Reply_Data.data,"CONNECT FAIL",12) == 0)
		{
			lastGprsCmdState = 2;
		}
		else if(memcmp(GPRS_Reply_Data.data,"CONNECT 115200",14) == 0)
		{
			lastGprsCmdState = 1;
		
			if(SysConfPara.m_GPRSMode == 59)
				signal_grade += 10;
			if(signal_grade > 32)
				signal_grade = 32;
			
		}
		else{
			//lastGprsCmdState = 0;
		}
	}
	InitGprsReplyData();
}

void GPRS_Reset(void)
{

	gprsLastCmd = CMD_GPRS_RESET;
	GPIO_SetBits(GPRS_RESET_IO,GPRS_RESET_PIN);
	delay_ms(50); //�ʵ���ʱ��ʱ������޷��ﵽ��λЧ��.ʵ���������С32ms.�ĵ���Ҫ������50ms
	GPIO_ResetBits(GPRS_RESET_IO,GPRS_RESET_PIN);	
}

void sendNextGprsCmdCh(void)
{
		if( GPRS_CMD_Data.TxIndex >= GPRS_CMD_Data.len )//TC��Ҫ ��SR+дDR ������0,�����͵����,��'\0'��ʱ���ø�if�жϹص�
	 {
			USART_ClearFlag(GPRS_USART, USART_FLAG_TC);//��ȻTCһֱ��set, TCIEҲ�Ǵ򿪵�,���»᲻ͣ�����ж�. clear������,���ùص�TCIE
			USART_ITConfig(GPRS_USART, USART_IT_TXE, DISABLE);
	 }
   else
	 {
			USART_SendData(GPRS_USART, GPRS_CMD_Data.data[GPRS_CMD_Data.TxIndex] );
			GPRS_CMD_Data.TxIndex++;
	 }
}

uint8_t getLastGprsCmd(void)
{
	return gprsLastCmd;
}
uint8_t getLastGprsCmdState(void)
{
	return lastGprsCmdState;
}
	
uint8_t gprsIsConnected(void)
{
	return m_gprsIsConnected;
}

void initGprsTrans(void)
{
	gprsTimeOutCounter = 0;
	gprsCmdErrCount = 0;
	isRetryGPRS = 0;
}

uint8_t tryToConnectGprs(void)
{

	u8 tmpData[4];	
	if(getLastGprsCmdState() == 1)
		{
			gprsCmdErrCount = 0;
			gprsTimeOutCounter = 0;
			switch(getLastGprsCmd())
			{
			case CMD_GPRS_START:
				#ifdef WAIT_CMD_SPACE
					if(waitCmdSpace(0xffff) == 0)
						break;
				#endif
				GPRS_Check();
				break;					
			case CMD_GPRS_CHECK:
				#ifdef WAIT_CMD_SPACE
					if(waitCmdSpace(0x2ff) == 0) //<<slj 15-11-11������ʱ�䣬ȷ���ܼ�⵽�ź�
						break;
				#endif
					//outLog("CMD_GPRS_CHECK success!\r\n");
				GPRS_Init();
				break;
			case CMD_GPRS_INIT:
				#ifdef WAIT_CMD_SPACE
					if(waitCmdSpace(0x2ff) == 0)
						break;
				#endif
				//outLog("CMD_GPRS_INIT success!\r\n");
				GPRS_CipMode();
				break;			
			case CMD_GPRS_CIPMODE:
				#ifdef WAIT_CMD_SPACE
					if(waitCmdSpace(0x2ff) == 0)
						break;
				#endif
					//outLog("CMD_GPRS_CIPMODE success!\r\n");					
				GPRS_CSQ_Signal();
				break;
			case CMD_GPRS_CSQ:
				#ifdef WAIT_CMD_SPACE
					if(waitCmdSpace(0x2ff) == 0)
						break;
				#endif
					//outLog("CMD_GPRS_CSQ success!\r\n");				
				GPRS_Start_Network();
				break;
			case CMD_GPRS_NETSTART:
				#ifdef WAIT_CMD_SPACE
					if(waitCmdSpace(0x2ff) == 0)
						break;
				#endif
					//outLog("CMD_GPRS_NETSTART success!\r\n");
				GPRS_Connect();
				break;
			case CMD_GPRS_CONNECT:
				//outLog("CMD_GPRS_CONNECT success!\r\n");
				m_gprsIsConnected = 1;
				return 1;
			default:
				break;
			}
		}
		else if(getLastGprsCmdState() > 1)
		{			
			gprsTimeOutCounter = 0;
			
			if(gprsCmdErrCount > 100)
			{
				gprsCmdErrCount = 0;
				GPRS_Reset();
				//outLog("gprsCmdErrCount more than 100!\r\n");
				return 2;
			}
			
			switch(getLastGprsCmd())
			{
				case CMD_GPRS_START:
					#ifdef WAIT_CMD_SPACE
					if(waitCmdSpace(0xffff) == 0)
						break;
				#endif
					//outLog("CMD_GPRS_Strat fail!\r\n");
					gprsCmdErrCount++;
					if(gprsCmdErrCount > 8)
					{
						gprsCmdErrCount = 0;
						GPRS_Check();
					}
					else
					GPRS_Start();
					break;
			case CMD_GPRS_CHECK:
				#ifdef WAIT_CMD_SPACE
					if(waitCmdSpace(0xffff) == 0)
						break;
				#endif
					//outLog("CMD_GPRS_CHECK fail!\r\n");
					gprsCmdErrCount++;
					if(gprsCmdErrCount > 8)
					{
						gprsCmdErrCount = 0;
						GPRS_Init();
					}
					else
					GPRS_Check();
				break;
			case CMD_GPRS_INIT:
				#ifdef WAIT_CMD_SPACE
					if(waitCmdSpace(0xffff) == 0)
						break;
				#endif
					//outLog("CMD_GPRS_INIT fail!\r\n");
					gprsCmdErrCount++;
					if(gprsCmdErrCount > 8)
					{
						gprsCmdErrCount = 0;
						GPRS_CipMode();
					}
					else
						GPRS_Init();
				break;
			case CMD_GPRS_CIPMODE:
				#ifdef WAIT_CMD_SPACE
					if(waitCmdSpace(0xffff) == 0)
						break;
				#endif
					//outLog("CMD_GPRS_CIPMODE fail!\r\n");
					gprsCmdErrCount++;
					if(gprsCmdErrCount > 8)
					{
						gprsCmdErrCount = 0;
						GPRS_CSQ_Signal();
					}
					else
						GPRS_CipMode();
				break;

			case CMD_GPRS_CSQ:
				#ifdef WAIT_CMD_SPACE
					if(waitCmdSpace(0xffff) == 0)
						break;
				#endif
					//outLog("CMD_GPRS_CSQ fail!\r\n");
					gprsCmdErrCount++;
					if(gprsCmdErrCount > 90) //��ȡ�����ź�Ҳ������������
					{
						gprsCmdErrCount = 0;
						GPRS_Start_Network();
					}
					else
						GPRS_CSQ_Signal();
				break;
			case CMD_GPRS_NETSTART:
				#ifdef WAIT_CMD_SPACE
					if(waitCmdSpace(0xffff) == 0)
						break;
				#endif
					//outLog("CMD_GPRS_NETSTART fail!\r\n");
					gprsCmdErrCount++;
					if(gprsCmdErrCount > 8)
					{
						gprsCmdErrCount = 0;
						GPRS_Connect();
					}
					else
						GPRS_Start_Network();
				break;
			case CMD_GPRS_CONNECT:
				#ifdef WAIT_CMD_SPACE
					if(waitCmdSpace(0xffff) == 0)
						break;
				#endif
					//outLog("CMD_GPRS_CONNECT fail!\r\n");
				gprsCmdErrCount += 8;
				GPRS_Connect();
				break;
			default:				
				//if(curGprsDataLen ==  WELD_DATA_SIZE)
				{
					gprsCmdErrCount++;
					lastGprsCmdState = 0;
					GPRS_Reset();
					isRetryGPRS += 1;
					//GPRS_Check();		//����
				}
				break;
			}
		}
		else
		{
			gprsTimeOutCounter++;			
			
			if(gprsTimeOutCounter > 80000) //800000
			{
				if((getLastGprsCmd() == CMD_GPRS_CONNECT	
					|| getLastGprsCmd() == CMD_GPRS_RESET) && gprsTimeOutCounter < 0xff00)//0xfff00
					return 0;
				
				if(getLastGprsCmd() == CMD_GPRS_NETSTART && gprsTimeOutCounter < 0x2fff00)//0x2fff00
					return 0;
				
				gprsTimeOutCounter = 0;
				
				//outLog("CMD  time out!\r\n");
				
				if(isRetryGPRS < 100)
				{
					isRetryGPRS += 1;
					GPRS_Start();
					//outLog("have try again!\r\n");
					//GPRS_Check();		//����
					return 0;
				}					
				else
				{
					//outLog("GPRS outtime reset!\r\n");
					GPRS_Reset();
					gprsCmdErrCount = 0;
					isRetryGPRS = 0;
					//curGprsDataLen = 0;
					return 2;
				}
				
			}
		}
		return 0;
}

uint8_t tryToSendGprsData(void)
{
	u8 tmpData[4];
	char str[50];
	uint8_t ret = 1;
	
	if(getLastGprsCmdState() == 1)
	{
		gprsTimeOutCounter = 0;
//		#ifdef WAIT_CMD_SPACE
//			if(waitCmdSpace(0xffff) == 0)
//				return 0;
//		#endif
		ret = processDataUpload();
		if(ret == 4)
		{
			return 1;
		}
		if(ret == 0)
		{			
			//�����ϴ����
			if(curUploadDataIndex() >= 0)
			{
#ifdef WITH_GPRS_LOG
				//sprintf(str,"update Upload mark %d",curUploadDataIndex());
				//addTFLog(str);
#endif
//				tmpData[0] = 0x38;
//				W25QXX_Write(tmpData,curUploadDataIndex(),1);
			}
			//EnableGpsUpdate();
			return 1;
		}
		else if(ret == 3)
		{
			return 3;
		}
	}
	else if(getLastGprsCmdState() > 1)
	{
		gprsTimeOutCounter = 0;
		#ifdef WAIT_CMD_SPACE
		if(waitCmdSpace(0xff) == 0)
			return 0;
		#endif
		ret = processDataUpload();
		if(ret == 3)
		{
			return 3;
		}
	}
	else
	{
		gprsTimeOutCounter++;	
		
		if(gprsTimeOutCounter < 0xffff) //0xffff00
			return 0;
		//outLog("GPRS send data timeout !\r\n");
//		if( timeoutCount < 5)
//		{
//			timeoutCount++;
//			GPRS_TxData();
//			return 0;
//		}
//		timeoutCount = 0;
		
		GPRS_Reset();
		gprsCmdErrCount = 0;
		isRetryGPRS = 0;
		m_gprsIsConnected = 0;
		
		return 2;
	}
	return 0;
}
/*********************************************END OF FILE**********************/
