#ifndef __CHECK_4G_SIM_H
#define __CHECK_4G_SIM_H

//#include "sys.h"
#include "delay.h"

void startTime4G();

void stopTime4G();

void flashCountAdd(void);

void checkSignalFlash(void);

u8 isExistSIM(void);

void initCheckConfig(void);

#endif