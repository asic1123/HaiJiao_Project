#include "Data_upload.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "DataConfig.h"
//#include "ParaManager.h"
//#include "bsp_24cxx.h"
#include "stm32f10x.h"
//#include "DataManager.h"
#include "bsp_checkcode.h"
#include "bsp_GPRS.h"
//#include "ff.h"
#include "CompileConfig.h"
//#include "SheepData.h"
//#include "PublicFunc.h"
//#include "LogInfo.h"
//#include "DogFacePhoto.h"
#include "DataStructConfig.h"
//---------------------------------------------

#define GPS_DATA_SIZE 43
#define GPRSID_LEN	11
#define GPRS_DATA_SIZE 500

//-----------------------------------------------

extern uint8_t lastGprsCmdState;

//---Data Upload ���ȿ���----
uint8_t uploadDataType = 0;
uint8_t m_curUploadPhotoIndex = 0;
int m_curUploadPhotoWeldIndex = -1;

uint8_t m_curUploadErrorCount = 0;
uint8_t photoFailState = 0;
enum UploadProcessEnum
{
	DATA_UPLOAD_INIT,
	DATA_UPLOADING,
	DATA_UPLOAD_END,
	PHOTO_UPLOAD_INIT,
	PHOTO_UPLOAD_NAME,
	PHOTO_UPLOADING,
	PHOTO_UPLOAD_NAP,
	PHOTO_UPLOAD_END,
	DOGFACE_UPLOAD_INIT,
	DOGFACE_UPLOADING,
	DOGFACE_END
};

uint8_t curUploadStep = DATA_UPLOAD_INIT;

//�ϴ�������ر���
uint16_t curGprsDataLen = 0;
char curGprsData[GPRS_DATA_SIZE];
char m_GprsID[GPRSID_LEN];

struct uploadDataStruct uploadData;
//struct Weld_Data_Struct m_curWeldData;

void initUploadData(void)
{
	memset(&uploadData,0,sizeof(struct uploadDataStruct));
}

/*
* pack_type  0:data 1:photo
* mark ����ʶ
* data ����/ָ��
* size ����/ָ���
*/
void UploadGprsPack(uint8_t pack_type,uint8_t mark,u8* data,uint32_t size)
{
#if DATA_UPLOAD_PROTOCOL_TYPE == 2
//	GPRS_WriteData(data,size);
	memcpy(uploadData.data,data,size);
	uploadData.len = size;	
	GPRS_TxData();
#elif DATA_UPLOAD_PROTOCOL_TYPE == 0 || DATA_UPLOAD_PROTOCOL_TYPE == 1
	uint16_t packLen;
	//��ͷ
	
	if(pack_type == 0)
	{
		uploadData.data[0] = 0x44;
		uploadData.data[1] = 0x54;
	}
	else if(pack_type == 1)
	{
		uploadData.data[0] = 0x52;
		uploadData.data[1] = 0x48;
	}else
	{
		uploadData.data[0] = 0x44;
		uploadData.data[1] = 0x46;
	}
	//����ʾ
	uploadData.data[2] = mark;
	//������
	packLen = size+2;
	uploadData.data[4] = packLen & 0xff;
	uploadData.data[3] = (packLen >> 8)& 0xff;
	//����
	memcpy(uploadData.data+5,data,size);
		
	//У���
	collating_data(uploadData.data+2,size+3);
	uploadData.len = packLen+5;
				
//	GPRS_WriteData(uploadData.data,uploadData.len);
	GPRS_TxData();
#endif
}

//-------------------------------Public----------------------------------

uint8_t curUploadDataType(void)
{
	return uploadDataType;
}

int curUploadDataIndex(void)
{
	return m_curUploadPhotoWeldIndex;
}

extern Trans_Data RFID_GPRS_Data;
uint8_t initDataUpload(uint8_t type,int index)
{
	char tmpStr[64];
	char tmpStr2[64];
	char valStr1[30] = {0};
	char valStr2[30] = {0};
	
	uploadDataType = type;
	
	switch(type)
	{
	case UPLOAD_GPS_DATA:
//		memcpy(curGprsData,zipCode,6);
//		memcpy(curGprsData+6,"GPSD",4);
//		memcpy(curGprsData+10,WeldMaCode,7);
//		
//		sprintf(tmpStr,";;%08dN%09dE;;FIN",(int)(Dimension*10000),(int)(Longitude*10000));

//		memcpy(curGprsData+17,tmpStr,26);
//		curGprsDataLen = GPS_DATA_SIZE;
		break;
	case UPLOAD_WELD_DATA:
		if(index < 0 || index >= methDataCount())
		{
			uploadDataType = 0;
			return 1;
		}
		memset(curGprsData,0,GPRS_DATA_SIZE);
		genGPRSMethData(index,(u8*)curGprsData,&curGprsDataLen);
		break;
	case UPLOAD_TEST_DATA:
		memset(curGprsData,0,GPRS_DATA_SIZE);
		memcpy(curGprsData,"hello world !!!",16);
		curGprsDataLen = 16;
		//memcpy(curGprsData,RFID_GPRS_Data.data,RFID_GPRS_Data.len);
		//curGprsDataLen = RFID_GPRS_Data.len;
		break;
	default:
		uploadDataType = 0;
		return 1;
	}
	
	return 0;
}

void startDataUpload(void)
{
//	u8 tmpData[1];
	initUploadData();
	
#if DATA_UPLOAD_PROTOCOL_TYPE == 2
	memcpy(uploadData.data,curGprsData,curGprsDataLen);
	UploadGprsPack(0,2,uploadData.data,curGprsDataLen);
//	UploadGprsPack(0,2,(u8*)curGprsData,curGprsDataLen);		//��������
	curUploadStep = DATA_UPLOADING;
#elif DATA_UPLOAD_PROTOCOL_TYPE == 0  ||  DATA_UPLOAD_PROTOCOL_TYPE == 1
//	tmpData[0] = 1;
//	UploadGprsPack(0,1,tmpData,1);
	uploadData.data[5] = 1;
	;	
	
	
	UploadGprsPack(0,1,uploadData.data+5,1);
	curUploadStep = DATA_UPLOAD_INIT;

#endif
}

uint8_t processDataUpload(void)
{
	uint8_t ret = 1;
//	u8 tmpData[TMP_LEN]; //<<slj 16-3-28 �ռ�̫������ջ������ʵ���Ϊȫ�ֱ���photo_tmpData
	static char fileName[64];
	char tmpFileName[64];
//	FRESULT result;
	uint32_t bw = 0;
	static int i;
	
	char tmpStr[20] = {0};
	char tmpStr1[20] = {0};
	char tmpStr2[20] = {0};
	char tmpStr3[64] = {0};
	
//	memset(photo_tmpData,0,TMP_LEN);
	
	if(getLastGprsCmdState() == 3)	//ʧ��
	{
		m_curUploadErrorCount = 0;
		
		switch(curUploadStep)
		{
		case 	PHOTO_UPLOAD_NAME:
			m_curUploadPhotoIndex++;
			lastGprsCmdState = 1;
			curUploadStep = PHOTO_UPLOAD_NAP;
			break;
		default:
			GPRS_TxData();
			break;
		}
#ifdef WITH_GPRS_LOG
		addTFLog("get replay - error 3");
#endif
	}
	else if(getLastGprsCmdState() > 1)	//ʧ��
	{
		if(m_curUploadErrorCount>5)
		{
			m_curUploadErrorCount = 0;
			return 3;
		}
		else
		{
			GPRS_TxData();
			m_curUploadErrorCount++;
		}
#ifdef WITH_GPRS_LOG
		addTFLog("get replay - error else");
#endif
	}
	else if(getLastGprsCmdState() == 1)
	{
		m_curUploadErrorCount = 0;
		
		initUploadData();
		
		switch(curUploadStep)
		{
		case 	DATA_UPLOAD_INIT:
			memcpy(uploadData.data+5,(u8*)curGprsData,curGprsDataLen);
			UploadGprsPack(0,2,(u8*)uploadData.data+5,curGprsDataLen);
//			UploadGprsPack(0,2,(u8*)curGprsData,curGprsDataLen);		//��������
			curUploadStep = DATA_UPLOADING;
			break;
		case 	DATA_UPLOADING:
#if DATA_UPLOAD_PROTOCOL_TYPE == 2
			ret = 0;
#elif DATA_UPLOAD_PROTOCOL_TYPE == 0 || DATA_UPLOAD_PROTOCOL_TYPE == 1
//			photo_tmpData[0] = 2;
//			UploadGprsPack(0,1,photo_tmpData,1);		//���ݴ������
			uploadData.data[5] = 2;
			UploadGprsPack(0,1,uploadData.data+5,1);
		
			curUploadStep = DATA_UPLOAD_END;
#endif
			break;
		case 	DATA_UPLOAD_END:

			ret = 0;
			break;
		default:
			ret = 0;
			break;
		}
	}
	
	return ret;
}


//------------------End-------------------------
