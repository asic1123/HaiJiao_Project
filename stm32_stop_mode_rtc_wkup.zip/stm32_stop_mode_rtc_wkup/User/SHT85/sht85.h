#ifndef _SHT85_h_ 
#define _SHT85_h_

#include "CompileConfig.h"
#include "stdint.h"


void SHT85_CheckAndConfig(void);
uint8_t SHT85_Write_CMD(uint8_t *_pWriteBuf, uint16_t CMD);
uint8_t SHT85_Read_Buffer(uint8_t *_pReadBuf);

#endif 

 
