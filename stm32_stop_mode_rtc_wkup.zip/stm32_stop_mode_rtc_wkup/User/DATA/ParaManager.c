#include "GobalDefine.h"
#include "ParaManager.h"
#include <string.h>
#include "PComunicate.h"
#include "ff.h"	
#include "LogInfo.h"
#include <stdio.h>

struct WeldingConfigStruct WeldingConfig = {'0'};
struct InfoConfigSturct InfoConfig;
struct SysConfParaSturct SysConfPara;

float PipeNominalResistance = 1.05;
float ResistanceFix = 0.07;

uint8_t HeatingTimeFixM = 0;
uint8_t HeatingTimeFixP = 0;

float realOutputVol = 39.5;
float PipeRealResistance = 0.0f;
float m_SaveRealResistance = 1.0; //����֮ǰ��¼ʵ����ֵ�����Ա��浽������
uint16_t inputVol = 220;
uint8_t valFrequency = 50;
float electricCurrent = 4;
float testCurrent = 12.8;

//�ʱ�
char zipCode[ZIP_CODE_LEN];
char WeldMaCode[WELD_MACODE_LEN];

double Dimension = 0; //ά��
double Longitude = 0; //����
char Satellite = 0; //��������

char out_Status = 0; //0��������������� 1����������˶�· 2����������˶�·

void initParaManager(void)
{
//	memcpy(zipCode,"200000",ZIP_CODE_LEN);	
//	memcpy(WeldMaCode,"30015EF",WELD_MACODE_LEN);	//�������HWDxxx 20xx-SUPPER-0xx
	resetParas();
	
	CallForDataInfo();
}

void updateSoftVersion(void)
{
	//��TF����д�������汾��
	FRESULT result;
	FIL file;
	uint32_t bw;
	char tmpStr[64];
	
	sprintf(tmpStr,"%02x.%02x.%02x",MAJOR_VERSION,MINOR_VERSION,RELEASE_VERSION);
	
	//�������
	result = f_open(&file, "0:version.txt", FA_OPEN_EXISTING | FA_WRITE);
	
	if(result != FR_OK)
	{
		result = f_open(&file, "0:version.txt", FA_CREATE_NEW | FA_WRITE);
	}
	
	if (result ==  FR_OK)
	{
		result = f_write(&file, tmpStr, 8, &bw);	

		f_close(&file);		
	}
	
}

void updateWelderInfoData(void)
{
	//��TF����д�뺸����� �ʱ�
	FRESULT result;
	FIL file;
	uint32_t bw;
	char tmpStr[64];
	
	
	//�������
	result = f_open(&file, "0:WeldMaCode", FA_OPEN_EXISTING | FA_WRITE);
	
	if(result != FR_OK)
	{
		result = f_open(&file, "0:WeldMaCode", FA_CREATE_NEW | FA_WRITE);
	}
	
	if (result ==  FR_OK)
	{
		result = f_write(&file, WeldMaCode, WELD_MACODE_LEN, &bw);	

		f_close(&file);
		
	}
	
	//�ʱ�
	result = f_open(&file, "0:zipCode", FA_OPEN_EXISTING | FA_WRITE);
	
	if(result != FR_OK)
	{
		outLog("0:zipCode is not exist and to create!\r\n");
		result = f_open(&file, "0:zipCode", FA_CREATE_NEW | FA_WRITE);
	}
	
	if(result ==  FR_OK)
	{
		outLog("0:zipCode open success ready to write!\r\n");
		result = f_write(&file, zipCode, ZIP_CODE_LEN, &bw);

		f_close(&file);
		
	}
	
	initMaInfo();
}

void initMaInfo(void)
{
	//��TF���� ��ȡ������� �ʱ�
	FRESULT result;
	FIL file;
	uint32_t bw;
	char tmpStr[64];
	
	
	//�������
	result = f_open(&file, "0:WeldMaCode", FA_OPEN_EXISTING | FA_READ);
	
	if (result ==  FR_OK && file.fsize != file.fptr)
	{
		result = f_read(&file, tmpStr, WELD_MACODE_LEN, &bw);
		
		if(result ==  FR_OK && bw == WELD_MACODE_LEN)
		{
			memcpy(WeldMaCode,tmpStr,WELD_MACODE_LEN);
			
			f_close(&file);
		}
	}
	
	//�ʱ�
	result = f_open(&file, "0:zipCode", FA_OPEN_EXISTING | FA_READ);
	
	if (result ==  FR_OK && file.fsize != file.fptr)
	{
		result = f_read(&file, tmpStr, ZIP_CODE_LEN, &bw);
		
		if(result ==  FR_OK && bw == ZIP_CODE_LEN)
		{
			memcpy(zipCode,tmpStr,ZIP_CODE_LEN);
			
			f_close(&file);
		}
	}
}

void resetParas(void)
{
	memset(InfoConfig.WelderNumber,'-',WELDER_NUM_LEN);
	memset(InfoConfig.ProjectNum,'-',PROJECT_NUM_LEN);
	memset(InfoConfig.CompanyNum,'-',COMPANY_NUM_LEN);
	memset(InfoConfig.ConstructNum,'-',CONSTRUCT_NUM_LEN);
	memset(InfoConfig.DeviceManaNum,'-',DEVICE_MANA_NUM_LEN);
	memset(InfoConfig.ManagerNum,'-',MANAGER_NUM_LEN);
		
	memset(InfoConfig.jly_num,'-',JLY_NUM_LEN);		//����Ա
	memset(InfoConfig.zjy_num,'-',ZJY_NUM_LEN); 		//�ʼ�Ա
	memset(InfoConfig.gcgly_num,'-',GCGLY_NUM_LEN); 		//���̹���Ա 
	memset(InfoConfig.ManagerNumExtern,'-',MANAGER_NUM_EXTERN_LEN);	//��Ŀ���������չλ
	
	memcpy(InfoConfig.HeatingTime,"0020",HEATING_TIME_NUM_LEN);
	memcpy(InfoConfig.ColdingTime,"0020",COLDING_TIME_NUM_LEN);
	memcpy(InfoConfig.PipeDiameter,"315",3);
	resetWeldPortNum();

	InfoConfig.VCompFactor = 0;
	InfoConfig.RCompFactor = 0;
	InfoConfig.UICompFactor = 0;
	InfoConfig.OutputVol = 39.5;
	InfoConfig.PipeFactory = '0';
	InfoConfig.PipeType = '0';
	
	InfoConfig.repDataTime.tm_year=2016;
	InfoConfig.repDataTime.tm_mon=1;
	InfoConfig.repDataTime.tm_mday=1;
	InfoConfig.repDataTime.tm_hour=0;
	InfoConfig.repDataTime.tm_hour=0;
	InfoConfig.repDataTime.tm_hour=0;
	
//	memset(InfoConfig.SIMCard,'-',13);

	InfoConfig.RRCompFactor = 0;
	
	InfoConfig.TempCompFactor = 0;
	
}

void resetWeldPortNum(void)
{
#if DATA_UPLOAD_PROTOCOL_TYPE == 2
	memcpy(InfoConfig.WeldPortNum,"1001",4);
#elif DATA_UPLOAD_PROTOCOL_TYPE == 1
	memcpy(InfoConfig.WeldPortNum,"D001",4);
#else
	memcpy(InfoConfig.WeldPortNum,"0001",4);
#endif
}

void initSysConfPara(void)
{
	SysConfPara.m_UpdateFlag = 0;
	SysConfPara.m_GPRSMode = 2;
}
//---------------------end-----------------------
