#include "DataManager.h"
#include "CompileConfig.h"
#include "bsp_i2c_ee.h"
#include "bsp_24cxx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "bsp_GPRS.h"
#include "ProcessManager.h"
#include "WatchDog.h"
#include "DataConfig.h"
#include "Data_upload.h"
#include "delay.h"
#include "pcf8563.h"
#include "bsp_date.h"
#include "bsp_rtc.h"

//-------------------
int8_t outSideTemp = 0;

uint16_t curErrorCode = 0;

uint8_t curLockWisePos = 0;
uint8_t lockWise[8] = {1,3,4,6,7,5,2,4};

//---------------------------------
uint8_t isUpdateWeldData = 0;
//------------------------------

uint16_t EEP_dataCount =0;

uint16_t printStartIndex = 0;
uint16_t printEndIndex = 0;
uint16_t curPrintIndex = 0;
uint16_t curSubPrintIndex = 0;

uint8_t gprsTransStep = 0;

extern uint8_t needSendGPRSData;
extern u32 cmd_space;
#define WELD_DATA_MAX 500
//------------------Private---------

//ÿ��1��Сʱ��������
extern uint8_t needSendGPRSDataTest;
void updataMethData(void)
{
	static int TestDiv = 0;
	switch(systmtime.tm_hour)
	{
		case 2:
		case 4:
		case 6:
		case 8:
		case 10:
		case 12:
		case 14:
		case 16:
		case 18:
		case 20:
		case 22:
		case 24:
			ReadMethInfo();
			MethInfo.index++;
			WriteMethData((u8*)&MethData,MethInfo.index,0,METH_DATA_SIZE);
			WriteMethInfo();
		
			if(systmtime.tm_hour == 24)
			{
				MethInfo.index_head = MethInfo.index;
				WriteMethInfo();
			}
			break;
		default:
			break;
	}

//	needSendGPRSData = 1;
	

	if(TestDiv > 30000000) //3���ӷ�һ��
	{
		TestDiv = 0;
		needSendGPRSDataTest = 1;
	}else
		TestDiv++;
	
}
//-----------------public-------------------

void initSysConfig(void) //��ȡϵͳ����
{
	char tmp[16] = {0};
	char isUpdate = 0;
	
	ReadSysConfPara();
	readEEP_FlagInfo();
	ReadMethInfo();
	
	//EEP_FlagInfo ��Ϊ1 ��ʼ��EEPROM
	if(EEP_FlagInfo != 1){
		memset(SysConfPara.MachinaryCode,'-',METHER_ID_LEN);
		memset(SysConfPara.ManholeCoverCode,'-',MANHOLECOVER_ID_LEN);
		memset(SysConfPara.GPRS_IP,'-',15);
		memset(SysConfPara.GPRS_Port,'-',6);
		
		memcpy(SysConfPara.GPRS_IP,"180.167.43.62",15);
		memcpy(SysConfPara.GPRS_Port,"10002",5);
		memcpy(SysConfPara.ZipCode,"200000",6);
		
		MethInfo.index = 0;
		MethInfo.count = 100;
		delay_ms(50);
		WriteSysConfPara();
		WriteMethInfo();
		writeEEP_FlagInfo(1);
	}
	memset(SysConfPara.ManholeCoverCode,'-',MANHOLECOVER_ID_LEN);
#if 1 //����ʹ��
	memcpy(SysConfPara.ZipCode,"200000",6);
	memcpy(SysConfPara.MachinaryCode,"JS2019",6);
	memcpy(SysConfPara.ManholeCoverCode,"0001",4);
	
	memcpy(MethData.MethConcetration,"0.02",4);
	memcpy(MethData.LightIntensity,"2122",4);
	memcpy(MethData.ManholeCoverStatus,"1",1);
	memcpy(MethData.ValveWell,"20",3);
	memcpy(MethData.DataTime,"1906271456",10);
	memcpy(MethData.Latitude_Longitude,"121179635E31216628N",19);
	memcpy(MethData.MachinaryErrflag,"00",2);
	memcpy(MethData.AlarmErrflag,"00",2);
	
	MethInfo.index = 1;
	MethInfo.count = 100;
	MethInfo.index_head = 1;
	MethInfo.index_tail = 1;
	
	WriteMethData((u8*)&MethData,MethInfo.index,0,METH_DATA_SIZE);
	WriteMethInfo();
#endif
	
	EEP_dataCount = MethInfo.count;	
}

void initDataManager(void)
{

}

void updateConfigInfoData(void)
{

}

void updateSysConfPara(void)
{
//	WriteSysConfPara();
}

void resetCurDataInfo(void)
{

}

 uint16_t methDataCount(void)
{
	return EEP_dataCount;
}

void clearAllData(void)
{
	EEP_dataCount = 0;
}

void clearGPRSFlag(uint16_t startIndex, uint16_t endIndex)
{
//	u8 tmpData[WELD_DATA_MAX] = {0};
//	W25QXX_Write(tmpData,startIndex-1,endIndex-startIndex+1);
}

//��������Ƿ��Ѿ�ȫ���ϴ�
char cheakUploadFlag(void)
{
	uint16_t i=0;
	u8 tmpData[4];
	for(i=0;i<methDataCount();i++)
	{
//		W25QXX_Read(tmpData,i,1);
		if(tmpData[0] != 0x38)
			return 1;
	}
	return 0;
}

void tryClearAllData(void)
{
	
}

uint8_t isGprsTransOn(void)
{
	return gprsTransStep;
}

void outputGprsData(int index)
{
	char str[50];
	
	if(index < 0 || index >=  EEP_dataCount)
		return;
	
	if(gprsTransStep) 
		return;
	
	if(initDataUpload(UPLOAD_WELD_DATA,index))
		return;

	initGprsTrans();
#ifdef WAIT_CMD_SPACE
	cmd_space = 0;
#endif

	if(gprsIsConnected())
	{
		gprsTransStep = 1;
		startDataUpload();
//#ifdef WITH_GPRS_LOG
//		sprintf(str,"Start Data Upload %d",index);
//		addTFLog(str);
//#endif
	}
	else
	{

		GPRS_Start();
		
//#ifdef WITH_GPRS_LOG
//	sprintf(str,"try to connect server");
//	addTFLog(str);
//#endif
		gprsTransStep = 2;		
	}
}

void outputGprsDataTest(void)
{
	char str[50];
	
	if(gprsTransStep) 
		return;
	
	if(initDataUpload(UPLOAD_TEST_DATA,1))
		return;

	initGprsTrans();
#ifdef WAIT_CMD_SPACE
	cmd_space = 0;
#endif

	if(gprsIsConnected())
	{
		gprsTransStep = 1;
		startDataUpload();
//#ifdef WITH_GPRS_LOG
//		sprintf(str,"Start Data Upload %d",index);
//		addTFLog(str);
//#endif
	}
	else
	{

		GPRS_Start();
		
//#ifdef WITH_GPRS_LOG
//	sprintf(str,"try to connect server");
//	addTFLog(str);
//#endif
		gprsTransStep = 2;		
	}
}

void tryOutputGprsData(void)
{
	u8 tmpData[4];
	uint8_t res = 0;
	
	switch(gprsTransStep)
	{
	case 1:	
	case 3:		//��������
		res = tryToSendGprsData();
		if(res== 1)
		{
			gprsTransStep = 0;
		}
		else if(res== 2)
		{
			gprsTransStep++;
			
			if(gprsTransStep == 2)
			{
				GPRS_Start();
			}
		}
		else if(res== 3)
		{
			gprsTransStep = 0;
		}
			
		break;
	case 2:		//��ʼ������
		res = tryToConnectGprs();
		if(res== 1)
		{
			startDataUpload();
			gprsTransStep = 3;
		}
		else if(res == 2)
		{
			gprsTransStep = 0;
		}
		break;
	default:
		gprsTransStep = 0;
		break;
	}
}
//---------------------end-----------------------
