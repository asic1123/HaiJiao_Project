#include "DataConfig.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "malloc.h"
#include "bsp_i2c_ee.h"
#include "bsp_24cxx.h"
#include "DataManager.h"
#include "PublicFunc.h"
#include "bsp_rtc.h"
#include "bsp_date.h"
#include "pcf8563.h"
#include "DataConfig.h"

struct SysConfParaSturct SysConfPara;
struct MethInfoStruct MethInfo;
struct Meth_Data_Struct MethData;
uint8_t EEP_FlagInfo = 0;

uint16_t MethInfo_EEP_headAddr =  (START_ADDR + SYSCONFPARA_DATA_SIZE);	//���ݱ�ǿ�ʼλ��
uint16_t MethData_EEP_headAddr =  (START_ADDR + SYSCONFPARA_DATA_SIZE + METH_INFO_SIZE);	//���ݴ洢��ʼλ��

void writeEEP_FlagInfo(uint8_t flag)
{
	EEP_FlagInfo = flag;
	unlock_EEPROM_WP();
	I2C_EE_BufferWrite(&EEP_FlagInfo, FLAG_ADDR, 1);
	lock_EEPROM_WP();
}

void readEEP_FlagInfo(void)
{
	I2C_EE_BufferRead(&EEP_FlagInfo, FLAG_ADDR, 1);
}

void ReadSysConfPara(void)
{
	I2C_EE_BufferRead((u8*)&SysConfPara, START_ADDR, SYSCONFPARA_DATA_SIZE);
}

void WriteSysConfPara(void)
{
	unlock_EEPROM_WP();
	I2C_EE_BufferWrite((u8*)&SysConfPara, START_ADDR, SYSCONFPARA_DATA_SIZE);
	lock_EEPROM_WP();
}

void ReadSysConfPara_Test(uint8_t* des)
{
	I2C_EE_BufferRead(des, START_ADDR, SYSCONFPARA_DATA_SIZE);
}

void ReadMethInfo(void)
{
	I2C_EE_BufferRead((u8*)&MethInfo, MethInfo_EEP_headAddr, METH_INFO_SIZE);
}

void WriteMethInfo(void)
{
	unlock_EEPROM_WP();
	I2C_EE_BufferWrite((u8*)&MethInfo, MethInfo_EEP_headAddr, METH_INFO_SIZE);
	lock_EEPROM_WP();
}

void ReadMethData(uint8_t* des,uint16_t index,uint16_t shift,uint16_t len)
{
	uint16_t count = 0;
//	if(methDataCount() < 1) return;	
//	count = (methDataCount()-1)/500;
//	
//	if(index < methDataCount() && index >= count*500)
		I2C_EE_BufferRead(des,MethData_EEP_headAddr+index*METH_DATA_SIZE+shift,len);
}

void WriteMethData(uint8_t* src,uint16_t index,uint16_t shift,uint16_t len)
{
	unlock_EEPROM_WP();
	I2C_EE_BufferWrite(src,MethData_EEP_headAddr+index*METH_DATA_SIZE+shift,len);
	lock_EEPROM_WP();
}

//���������ʽ����
void addOutputMethDataItem(uint8_t* des,uint8_t* src,uint16_t* pos,uint8_t size,uint8_t b_WithSemi)
{
#if SOFT_CUSTOMIZE_TYPE == 1
	char tmpStr[64];
	sprintf(tmpStr,"%.*s",size,src);
	removeLastReg(tmpStr,'-');	//ɾ��β����λ
	
	if(strlen(tmpStr) <= 0)
		sprintf(tmpStr," ");	//�������Ϊ�գ������ӿո�
	
	memcpy(des+(*pos),tmpStr,strlen(tmpStr));
	*pos += strlen(tmpStr);
#else
	memcpy(des+(*pos),src,size);
	*pos += size;
#endif
	if(b_WithSemi)
	{
		memcpy(des+(*pos),";;",2);
		*pos += 2;
	}
}

void genGPRSMethData(uint16_t index,uint8_t* des,uint16_t* size)
{
	uint16_t pos = 0;
	struct Meth_Data_Struct data;
	char tempStr[64];
	char tempStr1[64];
	
	ReadMethData((u8*)&data,index,0,METH_DATA_SIZE);
	
	//�ʱ�
	addOutputMethDataItem(des,SysConfPara.ZipCode,&pos,ZIP_CODE_LEN,0);
	//STM
	addOutputMethDataItem(des,"STM",&pos,3,0);
	//���Ʊ��
	sprintf(tempStr,"%.*s",METHER_ID_LEN,SysConfPara.MachinaryCode);
	removeLastReg(tempStr,'-');
	addOutputMethDataItem(des,tempStr,&pos,strlen(tempStr),1);
	
	//�Ѿ��Ǳ��
	sprintf(tempStr,"%.*s",METHER_ID_LEN,SysConfPara.ManholeCoverCode);
	removeLastReg(tempStr,'-');
	addOutputMethDataItem(des,tempStr,&pos,strlen(tempStr),1);
	
	//����Ũ��
	addOutputMethDataItem(des,data.MethConcetration,&pos,METH_CONCETRATION_LEN,1);
	
	//��ǿ
	addOutputMethDataItem(des,data.LightIntensity,&pos,LIGHT_INTENSITY_LEN,1);
	
	//�����Ƿ����
	addOutputMethDataItem(des,data.ManholeCoverStatus,&pos,MANHOLECOVER_STATUS_LEN,1);
	
	//�����¶�
	addOutputMethDataItem(des,data.ValveWell,&pos,VALVE_WELL_LEN,1);
	
	//���ʱ��
	addOutputMethDataItem(des,data.DataTime,&pos,DATA_TIME_LEN,1);
	
	//γ��N����E
	addOutputMethDataItem(des,data.Latitude_Longitude,&pos,GPS_LEN,1);
	
	//����״̬
	addOutputMethDataItem(des,data.MachinaryErrflag,&pos,ERROR_CODE_LEN,1);
	
	//������Ϣ
	addOutputMethDataItem(des,data.AlarmErrflag,&pos,ERROR_CODE_LEN,1);
	//FIN
	addOutputMethDataItem(des,"FIN",&pos,3,0);
	
	*size = pos;
}