#ifndef __DATA_MANAGER_H
#define __DATA_MANAGER_H

#include <stdint.h>
#include "CompileConfig.h"

//---------------------------
extern uint16_t curErrorCode;
//-------------------------
void updataMethData(void);


void initDataManager(void);
void updateConfigInfoData(void);
void readConfigInfoData(void);

void resetCurDataInfo(void);		//���õ�ǰ�������ݱ���
void addWeldData(void);
void updateWeldData(uint8_t errorType);
uint16_t methDataCount(void);

void clearAllData(void);
void tryClearAllData(void);


void outputUsbData(uint16_t startIndex,uint16_t endIndex);
void endOutputUsbData(void);
void tryOutputUsbData(void);

void outputWifiData(uint16_t startIndex,uint16_t endIndex);
void endOutputWifiData(void);
void tryOutputWifiData(void);

uint8_t isGprsTransOn(void);
void outputGprsData(int index);
void tryOutputGprsData(void);
void ouputGpsData(void);
void outputWELDNO_Data(void);
void outputFitting_Data(void);
void outputDogFaceData(void);
void outputAttendanceData(void);

void updateSysConfPara(void);

void initSysConfig(void); //��ȡϵͳ������Ϣ

void clearGPRSFlag(uint16_t startIndex, uint16_t endIndex);
//��������Ƿ��Ѿ�ȫ���ϴ�
char cheakUploadFlag(void);

void outputGprsDataTest(void);
#endif	//__DATA_MANAGER_H
//---------end----------
