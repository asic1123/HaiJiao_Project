#include "SystemConfigureFuncs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ParaManager.h"
#include "PublicFunc.h"

uint8_t setWelderNumber(char* str)
{
	if(isContainsIllegalityChar(str,strlen(str)))
	{
		return 0;
	}
		
	memset(InfoConfig.WelderNumber,'-',WELDER_NUM_LEN);
	memcpy(InfoConfig.WelderNumber,str,(strlen(str) > WELDER_NUM_LEN)?WELDER_NUM_LEN:strlen(str));
	
	return 1;
}

/////////////-------------EOF---------------

