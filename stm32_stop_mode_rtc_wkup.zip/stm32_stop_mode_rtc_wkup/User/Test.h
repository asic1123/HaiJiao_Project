#ifndef __TEST_H
#define __TEST_H

#include <stdint.h>
#include "DataStructConfig.h"

extern Trans_Data TestData1;
extern Trans_Data TestData2;
extern Trans_Data TestData3;
extern Trans_Data TestData4;
extern Trans_Data TestData5;

void TestUartInitData(void);
void TestUart1ENABLE(void);
void TestUart2ENABLE(void);
void TestUart3ENABLE(void);
void TestUart4ENABLE(void);
void TestUart5ENABLE(void);

void TestUart1(void);
void TestUart2(void);
void TestUart3(void);
void TestUart4(void);
void TestUart5(void);

void AddTestData(uint8_t ch);



#endif	//__TEST_H
//---------end----------
