/**
  ******************************************************************************
  * @file    bsp_i2c.c
  * @author  Eason
  * @version V1.0
  * @date    2014-09-15
  * @brief   I2CӦ�ú����ӿ�
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:Ұ�� iSO-MINI STM32 ������ 
  *
  ******************************************************************************
  */

#include "bsp_i2c.h"

/* Private define ------------------------------------------------------------*/
#define I2C1_SLAVE_ADDRESS7     0x30
#define I2C2_SLAVE_ADDRESS7     0x24
#define BufferSize              4
#define ClockSpeed              300000

/* Private variables ---------------------------------------------------------*/
//I2C_InitTypeDef  I2C_InitStructure;
u8 I2C_Buffer_Tx[4] = {0,3,9,5};
u8 I2C_Buffer_Rx[BufferSize] = {0};
u8 TxIdx = 0, RxIdx = 0;
volatile TestStatus TransferStatus = FAILED;

/******************************************************************************
* Function Name  : I2C_GPIO_Config
* Description     : Configures the different GPIO ports.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void I2C_GPIO_Config(void)
{
  	GPIO_InitTypeDef GPIO_InitStructure;

		/* Enable peripheral clocks --------------------------------------------------*/
  	/* GPIOB Periph clock enable */
  	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  	/* I2C1 and I2C2 Periph clock enable */
  	RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1 | RCC_APB1Periph_I2C2, ENABLE);

  	/* Configure I2C1 pins: SCL and SDA ----------------------------------------*/
  	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 | GPIO_Pin_7; //ѡ������õ�GPIO�ܽ�
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	//�ܽ�����50MHz
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;  //���ÿ�©���
  	GPIO_Init(GPIOB, &GPIO_InitStructure);

  	/* Configure I2C2 pins: SCL and SDA ----------------------------------------*/
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11;
  	GPIO_Init(GPIOB, &GPIO_InitStructure);
}

/*******************************************************************************
* Function Name  : I2C_Master_Init
* Description    : I2C Master initialize.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/ 
void I2C_Master_Init(void)
{
	I2C_InitTypeDef  I2C_InitStructure;
	/* I2C1 configuration ------------------------------------------------------*/
  	I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
  	I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
  	I2C_InitStructure.I2C_OwnAddress1 = I2C1_SLAVE_ADDRESS7;
  	I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
  	I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
  	I2C_InitStructure.I2C_ClockSpeed = ClockSpeed;
  	I2C_Init(I2C1, &I2C_InitStructure);

	I2C_Cmd(I2C1, ENABLE);
//	  /* Enable I2C1 event and buffer interrupt */
//  I2C_ITConfig(I2C1, I2C_IT_EVT | I2C_IT_BUF, ENABLE);
}

/*******************************************************************************
* Function Name  : I2C_Slave_Init
* Description    : I2C Slave initialize.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void I2C_Slave_Init(void)
{
	I2C_InitTypeDef  I2C_InitStructure;
  	/* I2C2 configuration ------------------------------------------------------*/
	I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
  	I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
  	I2C_InitStructure.I2C_OwnAddress1 = I2C2_SLAVE_ADDRESS7;
  	I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
  	I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
  	I2C_InitStructure.I2C_ClockSpeed = ClockSpeed;
  	I2C_Init(I2C2, &I2C_InitStructure);
	
	I2C_Cmd(I2C2, ENABLE);
	/* Enable  I2C2 event and buffer interrupt */
  I2C_ITConfig(I2C2, I2C_IT_EVT | I2C_IT_ERR | I2C_IT_BUF, ENABLE); 
}

void I2C_Mode_Init(void)
{
	I2C_GPIO_Config();
	I2C_Master_Init();
	I2C_Slave_Init();
}

/*******************************************************************************
* Function Name  : Buffercmp
* Description    : Compares two buffers.
* Input          : - pBuffer1, pBuffer2: buffers to be compared.
*                : - BufferLength: buffer's length
* Output         : None
* Return         : PASSED: pBuffer1 identical to pBuffer2
*                  FAILED: pBuffer1 differs from pBuffer2
*******************************************************************************/
TestStatus Buffercmp(u8* pBuffer1, u8* pBuffer2, u16 BufferLength)
{
  while(BufferLength--)
  {
    if(*pBuffer1 != *pBuffer2)
    {
      return FAILED;
    }
    
    pBuffer1++;
    pBuffer2++;
  }
  return PASSED;  
}

/*******************************************************************************
* Function Name  : I2C_Transmission
* Description    : Data Transmission.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void I2C_Transmission(void)
{
#if 0  //��-�жϷ�������
	I2C_GenerateSTART(I2C1, ENABLE);
  /* Test on I2C1 EV5 and clear it */
  while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT));   
  /* Send I2C2 slave Address for read*/
  I2C_Send7bitAddress(I2C1, I2C2_SLAVE_ADDRESS7, I2C_Direction_Receiver);
  /* Test on I2C1 EV6 and clear it */
  while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED));
		/* receive data */
		while(RxIdx < BufferSize-1)
		{ 
			/* Test on I2C1 EV7 and clear it */
			while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_RECEIVED));	 
			/* Store received data on I2C1 */
			I2C_Buffer_Rx[RxIdx++] = I2C_ReceiveData(I2C1);			
		}
   /* ��ACKʹ�ܣ�������Ӧ�� */
	I2C_AcknowledgeConfig(I2C1,DISABLE);
   /* ����ֹͣ�źţ��ض����� */
	I2C_GenerateSTOP(I2C1, ENABLE);
   /* Test on I2C1 EV7 �������һ������ */
  while(!I2C_GetFlagStatus(I2C1, I2C_FLAG_RXNE));
	I2C_Buffer_Rx[RxIdx++] = I2C_ReceiveData(I2C1); 

  RxIdx = 0;
  TxIdx = 0;
	
#else	//��-�жϽ�������
  I2C_GenerateSTART(I2C1, ENABLE);
  /* Test on I2C1 EV5 and clear it */
  while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT));   
  /* Send I2C2 slave Address for write*/
  I2C_Send7bitAddress(I2C1, I2C2_SLAVE_ADDRESS7, I2C_Direction_Transmitter);
  /* Test on I2C1 EV6 and clear it */
  while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));
		while(TxIdx < BufferSize)
		{
    /* SendData data on I2C1 */
			I2C_SendData(I2C1, I2C_Buffer_Tx[TxIdx++]);
			while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED));				
		}

	I2C_GenerateSTOP(I2C1, ENABLE);

  RxIdx = 0;
  TxIdx = 0;

  /* Check the corectness of written data */
  TransferStatus = Buffercmp(I2C_Buffer_Tx, I2C_Buffer_Rx,1/*BufferSize*/);

   #endif
}
