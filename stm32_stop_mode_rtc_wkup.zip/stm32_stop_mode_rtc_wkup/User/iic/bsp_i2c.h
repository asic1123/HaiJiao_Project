#ifndef __I2C_H
#define	__I2C_H

#include "stm32f10x.h"

/* Private typedef -----------------------------------------------------------*/
typedef enum {FAILED = 0, PASSED = !FAILED} TestStatus;

void I2C_Mode_Init(void);

void I2C_Transmission(void);

#endif /* __I2C_H */
