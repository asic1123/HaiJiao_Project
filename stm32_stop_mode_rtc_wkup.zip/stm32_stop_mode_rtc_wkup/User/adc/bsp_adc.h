#ifndef __ADC_H
#define	__ADC_H


#include "stm32f10x.h"

typedef struct
{
	float sample_value; //����ֵ
	float sum_squ; //ƽ����
	float avg_sqrt; //������
	float result;  //���ֵ
	uint16_t ADC_Avg; //�͸�DA�ڵ�����
}ADC_Sample_Data;

void ADC1_Init(void);
//uint8_t calcADCValue(void);
uint8_t calc_ADC_Value(void);
uint8_t calc_ADC_Voltage(void);

void ADC_TIM3_Config(void);

void initCurrent(void);
void initOutVoltag(void);
void initRes(void);

uint8_t calc_ADC_Res(void);

#endif /* __ADC_H */

