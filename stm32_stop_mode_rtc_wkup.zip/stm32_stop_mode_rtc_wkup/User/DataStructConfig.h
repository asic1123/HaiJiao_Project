#ifndef __DATA_STRUCT_CONFIG_H
#define __DATA_STRUCT_CONFIG_H
#include "stm32f10x.h"
#define TRANS_DATA_MAX_SIZE 600//300 
#define WIFI_PHOTO_DATA_MAX_SIZE 10580 //20580
typedef struct _USART_DATA 
{
	uint8_t data[TRANS_DATA_MAX_SIZE];
	uint16_t len;
	uint16_t TxIndex;
}Trans_Data;

typedef struct _PHOTO_DATA_STRUCT
{
	uint8_t* data;
	uint16_t len;
	uint16_t TxIndex;
}Photo_Data;

#endif	//__DATA_STRUCT_CONFIG_H
