#include "led.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "lcd.h"
#include "key.h"
#include "rtc.h"

 int main(void)
 {  
	u8 x=0;
	u8 lcd_id[12];			//���LCD ID�ַ���	
	 
	//for RTC integration
  u16 syear;
	u8 smon;
	u8 sday;
	u8 hour;
	u8 min;
	u8 sec;
	 
	u8 next_alarm_min;
	 
	u16 *al_syear;
	u8 *al_smon;
	u8 *al_sday;
	u8 *al_hour;
	u8 *al_min;
	u8 *al_sec;
	u8 t;
	 
	RTC_Get();
	syear = calendar.w_year;
	smon = calendar.w_month;
	sday = calendar.w_date;
	hour = calendar.hour;
	min = calendar.min;
	sec = calendar.sec;
	
	al_syear = &syear;
	al_smon = &smon;
	al_sday = &sday;
	al_hour = &hour;
	al_min = &min;
	al_sec = &sec;
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
  //end of RTC integration	 
	

	delay_init();	    	 //��ʱ������ʼ��	  
	uart_init(9600);	 	//���ڳ�ʼ��Ϊ9600
	LED_Init();		  		//��ʼ����LED���ӵ�Ӳ���ӿ�
 	LCD_Init();
	KEY_Init();
	
	//for RTC integration
  while(RTC_Init(syear,smon,sday,hour,min,sec))
	{ 
		LCD_ShowString(60,130,200,16,16,"RTC ERROR!   ");	
		delay_ms(800);
		LCD_ShowString(60,130,200,16,16,"RTC Trying...");	
	}		    					
	//end of RTC integration
	 
	POINT_COLOR=RED; 

	LCD_ShowString(30,40,200,24,24,"STM32F103 ^_^");	
	LCD_ShowString(30,70,200,16,16,"LOWPOWER TEST");
	LCD_ShowString(30,90,200,16,16,"SChen@HAIJIAO");      					 
//	LCD_ShowString(30,130,200,12,12,"2019/12/17");	      					 

	next_alarm_min = min + 1;
	RTC_Alarm_Set(syear,smon,sday,hour,next_alarm_min,sec);
	
	while(1)
	{
		if(t!=calendar.sec)
		{
			t=calendar.sec;
			LCD_ShowNum(60,130,calendar.w_year,4,16);									  
			LCD_ShowNum(100,130,calendar.w_month,2,16);									  
			LCD_ShowNum(124,130,calendar.w_date,2,16);	 
			switch(calendar.week)
			{
				case 0:
					LCD_ShowString(60,148,200,16,16,"Sunday   ");
					break;
				case 1:
					LCD_ShowString(60,148,200,16,16,"Monday   ");
					break;
				case 2:
					LCD_ShowString(60,148,200,16,16,"Tuesday  ");
					break;
				case 3:
					LCD_ShowString(60,148,200,16,16,"Wednesday");
					break;
				case 4:
					LCD_ShowString(60,148,200,16,16,"Thursday ");
					break;
				case 5:
					LCD_ShowString(60,148,200,16,16,"Friday   ");
					break;
				case 6:
					LCD_ShowString(60,148,200,16,16,"Saturday ");
					break;  
			}
			LCD_ShowNum(60,162,calendar.hour,2,16);									  
			LCD_ShowNum(84,162,calendar.min,2,16);									  
			LCD_ShowNum(108,162,calendar.sec,2,16);
			LED0=!LED0;
		}	
		delay_ms(1800);			
		delay_ms(1800);		
		delay_ms(1800);		
		delay_ms(1800);		
		delay_ms(1800);				
		
//		if(KEY_Scan(0)==KEY0_PRES){
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR,ENABLE);
			PWR_WakeUpPinCmd(ENABLE);
			PWR_EnterSTANDBYMode();
//	}
	
	} 
}
